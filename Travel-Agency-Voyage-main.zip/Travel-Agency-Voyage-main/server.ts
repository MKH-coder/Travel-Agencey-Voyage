// Deprecated - Architecture is pure Supabase SPA
export {};
