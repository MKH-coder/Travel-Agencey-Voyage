import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Header } from './components/Header.tsx';
import { HeroSection } from './components/HeroSection.tsx';
import { ListingCard } from './components/ListingCard.tsx';
import { DetailModal } from './components/DetailModal.tsx';
import { PackagePreviewModal } from './components/PackagePreviewModal.tsx';
import { SavedTripsModal } from './components/SavedTripsModal.tsx';
import { LoginModal } from './components/LoginModal.tsx';
import { AdminPortal } from './components/AdminPortal.tsx';
import { MapView } from './components/MapView.tsx';
import { Breadcrumbs } from './components/Breadcrumbs.tsx';
import { ShortcutsHelpModal } from './components/ShortcutsHelpModal.tsx';
import { ToastContainer } from './components/ToastContainer.tsx';
import { useGlobalShortcuts } from './hooks/useGlobalShortcuts.ts';
import { Listing, FilterState, ThemeMode } from './types.ts';
import { SupabaseDataService } from './services/supabaseService.ts';
import { ExploreFeed } from './components/ExploreFeed.tsx';
import {
  Compass,
  Sparkles,
  SearchX,
  ShieldCheck,
  Plane,
  ArrowRight,
  Map as MapIcon,
  LayoutGrid,
  Columns,
} from 'lucide-react';

import { MarketingSections } from './components/MarketingSections.tsx';
import { PackageCreatorModal } from './components/PackageCreatorModal.tsx';
import { CustomTripBuilderModal } from './components/CustomTripBuilderModal.tsx';
import { CustomTripsTrackerModal } from './components/CustomTripsTrackerModal.tsx';
import { Newsletter } from './components/Newsletter.tsx';
import { Footer } from './components/Footer.tsx';
import { FloatingContact } from './components/FloatingContact.tsx';

function MainLayout() {
  const { styles, theme, setTheme } = useTheme();
  const { user, token, showLoginModal, setShowLoginModal, showBypassModal, setShowBypassModal } = useAuth();

  const [currentView, setCurrentView] = useState<'dashboard' | 'admin'>('dashboard');
  const [feedLayout, setFeedLayout] = useState<'split' | 'grid' | 'map'>('split');
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(false);
  const [savedListings, setSavedListings] = useState<Listing[]>([]);

  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const [packagePreviewActive, setPackagePreviewActive] = useState(false);
  const [packageInitialListing, setPackageInitialListing] = useState<Listing | null>(null);
  const [showPackageCreatorModal, setShowPackageCreatorModal] = useState<boolean>(false);
  const [showCustomTripBuilderModal, setShowCustomTripBuilderModal] = useState<boolean>(false);
  const [showCustomTripsTrackerModal, setShowCustomTripsTrackerModal] = useState<boolean>(false);
  const [customTripInitialListing, setCustomTripInitialListing] = useState<Listing | null>(null);
  const [hoveredListingId, setHoveredListingId] = useState<string | null>(null);
  const [showSavedModal, setShowSavedModal] = useState(false);
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);
  const [adminTab, setAdminTab] = useState<'analytics' | 'create' | 'inventory' | 'queue' | 'users' | 'logs' | 'cloud' | 'logins' | 'packages' | 'custom-trips' | null>(null);

  const [filters, setFilters] = useState<FilterState>({
    category: 'ALL',
    search: '',
    priceRange: 'ALL',
    minRating: 0,
    country: 'All Countries',
  });

  const handleCycleTheme = useCallback(() => {
    const themeModes: ThemeMode[] = [
      'cyan-light',
      'dark-slate',
      'crimson-black',
      'emerald-warm',
      'royal-gold',
      'violet-glass',
      'emerald-black',
      'rose-gold',
      'nordic-frost',
    ];
    const currentIndex = themeModes.indexOf(theme);
    const nextTheme = themeModes[(currentIndex + 1) % themeModes.length];
    setTheme(nextTheme);
  }, [theme, setTheme]);

  const handleFocusSearch = useCallback(() => {
    if (currentView !== 'dashboard') {
      setCurrentView('dashboard');
    }
    setTimeout(() => {
      const heroInput = document.getElementById('hero-search-input') as HTMLInputElement | null;
      const headerInput = document.getElementById('header-search-input') as HTMLInputElement | null;
      if (heroInput) {
        heroInput.focus();
        heroInput.select();
        heroInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if (headerInput) {
        headerInput.focus();
        headerInput.select();
      }
    }, 50);
  }, [currentView]);

  const handleCloseAllModals = useCallback(() => {
    setSelectedListing(null);
    setPackagePreviewActive(false);
    setShowSavedModal(false);
    setShowShortcutsModal(false);
    if (showLoginModal) setShowLoginModal(false);
    if (showBypassModal) setShowBypassModal(false);
  }, [showLoginModal, setShowLoginModal, showBypassModal, setShowBypassModal]);

  useGlobalShortcuts({
    onFocusSearch: handleFocusSearch,
    onCloseModals: handleCloseAllModals,
    onToggleSavedTrips: () => setShowSavedModal(prev => !prev),
    onToggleHelp: () => setShowShortcutsModal(prev => !prev),
    onToggleTheme: handleCycleTheme,
    onSwitchView: () => setCurrentView(prev => (prev === 'dashboard' ? 'admin' : 'dashboard')),
    extraShortcuts: [
      { key: '1', description: 'Switch to Split Layout', action: () => setFeedLayout('split'), ignoreInputs: true },
      { key: '2', description: 'Switch to Grid Layout', action: () => setFeedLayout('grid'), ignoreInputs: true },
      { key: '3', description: 'Switch to Map Layout', action: () => setFeedLayout('map'), ignoreInputs: true },
    ],
  });

  const loadListings = async () => {
    try {
      setLoading(true);
      const serverItems = await SupabaseDataService.getListings();
      setListings(serverItems);
    } catch (err) {
      console.warn('Error loading listings from Supabase:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadListings();

    // Subscribe to real-time changes on listings table
    const subscription = SupabaseDataService.subscribeToListingChanges(() => {
      loadListings();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    let isMounted = true;
    if (user?.uid) {
      SupabaseDataService.getSavedTrips(user.uid)
        .then((list) => {
          if (!isMounted) return;
          if (Array.isArray(list)) {
            setSavedListings(list);
          }
        })
        .catch((err) => {
          console.warn('Error fetching saved trips:', err);
        });
    } else {
      setSavedListings([]);
    }
    return () => {
      isMounted = false;
    };
  }, [user]);

  const toggleSaveListing = async (item: Listing) => {
    const isCurrentlySaved = savedListings.some(l => l.id === item.id);
    const updated = isCurrentlySaved ? savedListings.filter(l => l.id !== item.id) : [...savedListings, item];
    setSavedListings(updated);

    if (user?.uid) {
      try {
        if (isCurrentlySaved) {
          await SupabaseDataService.removeSavedTrip(user.uid, item.id);
        } else {
          await SupabaseDataService.saveTrip(user.uid, item.id);
        }
      } catch (err) {
        console.error('Failed to sync saved trip with Supabase:', err);
      }
    }
  };

  const removeSavedListing = async (id: string) => {
    const updated = savedListings.filter(l => l.id !== id);
    setSavedListings(updated);

    if (user?.uid) {
      try {
        await SupabaseDataService.removeSavedTrip(user.uid, id);
      } catch (err) {
        console.error('Failed to remove saved trip from Supabase:', err);
      }
    }
  };

  const filteredListings = useMemo(() => {
    const filtered = listings.filter(item => {
      if (item.status && item.status !== 'PUBLISHED') {
        return false;
      }
      if (filters.category !== 'ALL' && item.category !== filters.category) {
        return false;
      }
      if (filters.country !== 'All Countries' && item.country.toLowerCase() !== filters.country.toLowerCase()) {
        return false;
      }
      if (filters.search) {
        const rawQuery = filters.search.trim().toLowerCase();
        const normQuery = rawQuery.replace(/[^a-z0-9]/g, '');
        const fuzzyQuery = rawQuery.replace(/nn/g, 'n').replace(/mm/g, 'm').replace(/ll/g, 'l');

        const testMatch = (text?: string): boolean => {
          if (!text) return false;
          const lower = text.toLowerCase();
          if (lower.includes(rawQuery)) return true;
          const norm = lower.replace(/[^a-z0-9]/g, '');
          if (norm.includes(normQuery)) return true;
          const fuzzy = lower.replace(/nn/g, 'n').replace(/mm/g, 'm').replace(/ll/g, 'l');
          return fuzzy.includes(fuzzyQuery);
        };

        const matchesTitle = testMatch(item.title);
        const matchesLocation = testMatch(item.location);
        const matchesCountry = testMatch(item.country);
        const matchesDescription = testMatch(item.description);
        const matchesDuration = testMatch(item.duration);
        const matchesTags = item.tags?.some(t => testMatch(t));
        const matchesAmenities = item.amenities?.some(a => testMatch(a));

        // Search within bundle / tour package referenced sub-listings
        const matchesSubListings = item.listingIds?.some(id => {
          const sub = listings.find(l => l.id === id);
          if (!sub) return false;
          return (
            testMatch(sub.title) ||
            testMatch(sub.location) ||
            testMatch(sub.country) ||
            testMatch(sub.description) ||
            sub.tags?.some(t => testMatch(t)) ||
            sub.amenities?.some(a => testMatch(a))
          );
        });

        if (
          !matchesTitle &&
          !matchesLocation &&
          !matchesCountry &&
          !matchesDescription &&
          !matchesDuration &&
          !matchesTags &&
          !matchesAmenities &&
          !matchesSubListings
        ) {
          return false;
        }
      }
      if (filters.priceRange === 'UNDER_200' && item.price >= 200) return false;
      if (filters.priceRange === '200_400' && (item.price < 200 || item.price > 400)) return false;
      if (filters.priceRange === 'ABOVE_400' && item.price <= 400) return false;
      if (filters.minRating > 0 && item.rating < filters.minRating) return false;
      return true;
    });

    return filtered.sort((a, b) => {
      const timeA = new Date(a.timestamps.createdAt).getTime();
      const timeB = new Date(b.timestamps.createdAt).getTime();
      return timeB - timeA;
    });
  }, [listings, filters]);

  const handleBrowsePackages = useCallback(() => {
    setFilters(prev => ({ ...prev, category: 'PACKAGE' }));
    const exploreEl = document.getElementById('explore-feed-section') || document.querySelector('main');
    if (exploreEl) {
      exploreEl.scrollIntoView({ behavior: 'smooth' });
    }
    const pkg = listings.find(l => l.category === 'PACKAGE' && l.status === 'PUBLISHED') || listings.find(l => l.category === 'PACKAGE');
    if (pkg) {
      setSelectedListing(pkg);
      setPackagePreviewActive(true);
    } else {
      setSelectedListing({
        id: 'pkg-kyoto-zen-01',
        title: 'Kyoto Zen & Gastronomy Signature Package',
        category: 'PACKAGE',
        price: 780,
        rating: 4.99,
        reviewCount: 14,
        location: 'Arashiyama & Gion',
        country: 'Japan',
        description: 'Immerse yourself in Kyoto heritage with a luxury riverside stay at Hoshinoya, an authentic Michelin-grade Kaiseki dinner at Gion Karyo, private tea master ceremony, and chauffeured transfers.',
        images: [
          'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1200&q=80'
        ],
        status: 'PUBLISHED',
        createdBy: 'mukundkrishna2008@gmail.com',
        createdByName: 'Mukund Krishna',
        listingIds: ['list-hotel-kyoto-04', 'list-dining-kyoto-03'],
        tags: ['Zen Bundle', 'Kyoto Heritage', 'Best Value', 'Tour Package', 'VIP Concierge'],
        amenities: ['Cultural Concierge', 'Private Boat Transfer', 'Priority Dining Reservation', 'Guided Historic Walk'],
        duration: '4 Days / 3 Nights',
        timestamps: { createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }
      });
      setPackagePreviewActive(true);
    }
  }, [listings]);

  const handlePlanTrip = useCallback(() => {
    setCustomTripInitialListing(null);
    setShowCustomTripBuilderModal(true);
  }, []);

  const handleCustomTripFromListing = useCallback((listing: Listing) => {
    setCustomTripInitialListing(listing);
    setShowCustomTripBuilderModal(true);
  }, []);

  const handleCreatePackageFromListing = useCallback((listing: Listing) => {
    setPackageInitialListing(listing);
    setShowPackageCreatorModal(true);
  }, []);

  return (
    <div className={`min-h-screen w-full max-w-full overflow-x-hidden ${styles.bg} ${styles.textPrimary} transition-colors duration-300 flex flex-col font-sans selection:bg-cyan-500/20`}>
      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        savedTripsCount={savedListings.length}
        onOpenSavedTrips={() => setShowSavedModal(true)}
        onOpenShortcutsHelp={() => setShowShortcutsModal(true)}
        onOpenCustomTripBuilder={() => {
          setCustomTripInitialListing(null);
          setShowCustomTripBuilderModal(true);
        }}
        onOpenCustomTripsTracker={() => setShowCustomTripsTrackerModal(true)}
        searchQuery={filters.search}
        setSearchQuery={(q) => setFilters(prev => ({ ...prev, search: q }))}
      />

      <Breadcrumbs
        currentView={currentView}
        setCurrentView={setCurrentView}
        selectedListing={selectedListing}
        setSelectedListing={setSelectedListing}
        filters={filters}
        setFilters={setFilters}
        adminTab={adminTab}
      />

      <main className="flex-1">
        {currentView === 'dashboard' ? (
          <div className="space-y-8">
            <HeroSection 
              filters={filters} 
              setFilters={setFilters} 
              totalCount={filteredListings.length}
              onBrowsePackages={handleBrowsePackages}
              onPlanTrip={handlePlanTrip}
            />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 space-y-6">
              <ExploreFeed />

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200/60 dark:border-slate-800 pb-4">
                <div>
                  <h2 className={`text-xl font-extrabold tracking-tight ${styles.textPrimary} flex items-center gap-2 flex-wrap`}>
                    <Sparkles className="w-5 h-5 text-sky-500" />
                    <span>Featured Travel Collections</span>
                  </h2>
                  <p className={`text-xs ${styles.textMuted} mt-0.5`}>
                    Showing {filteredListings.length} hand-vetted destinations, five-star accommodations, and culinary experiences
                  </p>
                </div>

                <div className="flex items-center flex-wrap gap-2.5">
                  <div className={`p-1 rounded-2xl border ${styles.border} ${styles.cardBg} flex items-center gap-1 shadow-sm`}>
                    <button
                      id="view-mode-split"
                      onClick={() => setFeedLayout('split')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        feedLayout === 'split' ? `${styles.accent} text-white shadow-sm` : `${styles.textSecondary} hover:text-slate-900 dark:hover:text-white`
                      }`}
                    >
                      <Columns className="w-3.5 h-3.5" />
                      <span>Split View</span>
                    </button>
                    <button
                      id="view-mode-grid"
                      onClick={() => setFeedLayout('grid')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        feedLayout === 'grid' ? `${styles.accent} text-white shadow-sm` : `${styles.textSecondary} hover:text-slate-900 dark:hover:text-white`
                      }`}
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>Grid View</span>
                    </button>
                    <button
                      id="view-mode-map"
                      onClick={() => setFeedLayout('map')}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                        feedLayout === 'map' ? `${styles.accent} text-white shadow-sm` : `${styles.textSecondary} hover:text-slate-900 dark:hover:text-white`
                      }`}
                    >
                      <MapIcon className="w-3.5 h-3.5" />
                      <span>Map View</span>
                    </button>
                  </div>

                  <span className={`text-xs font-semibold px-2.5 py-1.5 rounded-xl border ${styles.accentBadge}`}>
                    {filters.country === 'All Countries' ? 'Worldwide Explorer' : filters.country}
                  </span>
                </div>
              </div>

              {feedLayout === 'map' ? (
                <div className="h-[650px] rounded-3xl overflow-hidden shadow-lg border border-slate-200/80 dark:border-slate-800">
                  <MapView
                    listings={filteredListings}
                    activeListingId={hoveredListingId || selectedListing?.id}
                    savedListingIds={savedListings.map(l => l.id)}
                    onSelectListing={(item) => {
                      setSelectedListing(item);
                      if (item.category === 'PACKAGE') setPackagePreviewActive(true);
                    }}
                    onToggleSave={toggleSaveListing}
                    className="h-full w-full"
                    isCompact={false}
                  />
                </div>
              ) : feedLayout === 'split' ? (
                <div className="space-y-6">
                  <div className="h-[380px] rounded-3xl overflow-hidden shadow-md border border-slate-200/80 dark:border-slate-800">
                    <MapView
                      listings={filteredListings}
                      activeListingId={hoveredListingId || selectedListing?.id}
                      savedListingIds={savedListings.map(l => l.id)}
                      onSelectListing={(item) => {
                        setSelectedListing(item);
                        if (item.category === 'PACKAGE') setPackagePreviewActive(true);
                      }}
                      onToggleSave={toggleSaveListing}
                      className="h-full w-full"
                      isCompact={true}
                    />
                  </div>

                  {loading ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {[1, 2, 3, 4, 5, 6].map(i => (
                        <div key={i} className={`h-96 rounded-2xl border ${styles.border} ${styles.cardBg} animate-pulse p-4 flex flex-col justify-between`}>
                          <div className="aspect-[16/10] bg-slate-200 dark:bg-slate-800 rounded-xl" />
                          <div className="space-y-2 mt-4">
                            <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
                            <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                          </div>
                          <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-xl mt-4" />
                        </div>
                      ))}
                    </div>
                  ) : filteredListings.length === 0 ? (
                    <div className={`p-12 rounded-3xl border ${styles.border} ${styles.cardBg} text-center space-y-4 max-w-lg mx-auto my-8`}>
                      <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                        <SearchX className="w-8 h-8" />
                      </div>
                      <h3 className={`text-lg font-bold ${styles.textPrimary}`}>No Matching Destinations Found</h3>
                      <p className={`text-xs ${styles.textMuted} leading-relaxed`}>
                        We couldn't find any travel experiences matching "{filters.search || filters.country}". Try broadening your search or resetting filters.
                      </p>
                      <button
                        onClick={() => setFilters({ category: 'ALL', search: '', priceRange: 'ALL', minRating: 0, country: 'All Countries' })}
                        className={`px-4 py-2 rounded-xl text-xs font-bold ${styles.buttonPrimary} shadow-md`}
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
                      {filteredListings.map(listing => (
                        <div key={listing.id} onMouseEnter={() => setHoveredListingId(listing.id)} onMouseLeave={() => setHoveredListingId(null)}>
                          <ListingCard
                            listing={listing}
                            isSaved={savedListings.some(l => l.id === listing.id)}
                            onToggleSave={toggleSaveListing}
                            onCreatePackage={handleCreatePackageFromListing}
                            onSelect={(item) => {
                              setSelectedListing(item);
                              if (item.category === 'PACKAGE') setPackagePreviewActive(true);
                            }}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div>
                  {loading ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      {[1, 2, 3, 4, 5, 6].map(i => (
                        <div key={i} className={`h-96 rounded-2xl border ${styles.border} ${styles.cardBg} animate-pulse p-4 flex flex-col justify-between`}>
                          <div className="aspect-[16/10] bg-slate-200 dark:bg-slate-800 rounded-xl" />
                          <div className="space-y-2 mt-4">
                            <div className="h-4 bg-slate-200 dark:bg-slate-800 rounded w-3/4" />
                            <div className="h-3 bg-slate-200 dark:bg-slate-800 rounded w-1/2" />
                          </div>
                          <div className="h-8 bg-slate-200 dark:bg-slate-800 rounded-xl mt-4" />
                        </div>
                      ))}
                    </div>
                  ) : filteredListings.length === 0 ? (
                    <div className={`p-12 rounded-3xl border ${styles.border} ${styles.cardBg} text-center space-y-4 max-w-lg mx-auto my-8`}>
                      <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                        <SearchX className="w-8 h-8" />
                      </div>
                      <h3 className={`text-lg font-bold ${styles.textPrimary}`}>No Matching Destinations Found</h3>
                      <p className={`text-xs ${styles.textMuted} leading-relaxed`}>
                        We couldn't find any travel experiences matching "{filters.search || filters.country}". Try broadening your search or resetting filters.
                      </p>
                      <button
                        onClick={() => setFilters({ category: 'ALL', search: '', priceRange: 'ALL', minRating: 0, country: 'All Countries' })}
                        className={`px-4 py-2 rounded-xl text-xs font-bold ${styles.buttonPrimary} shadow-md`}
                      >
                        Reset All Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
                      {filteredListings.map(listing => (
                        <ListingCard
                          key={listing.id}
                          listing={listing}
                          isSaved={savedListings.some(l => l.id === listing.id)}
                          onToggleSave={toggleSaveListing}
                          onCreatePackage={handleCreatePackageFromListing}
                          onSelect={(item) => {
                            setSelectedListing(item);
                            if (item.category === 'PACKAGE') setPackagePreviewActive(true);
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ) : (
          <AdminPortal
            onListingUpdated={loadListings}
            onNavigateExplore={() => setCurrentView('dashboard')}
            onTabChange={(tab) => setAdminTab(tab as 'analytics' | 'create' | 'inventory' | 'queue' | 'users' | 'logs' | 'cloud' | 'logins')}
          />
        )}

        {currentView === 'dashboard' && (
          <>
            <MarketingSections 
              onPlanTrip={handlePlanTrip}
              onBrowsePackages={handleBrowsePackages}
              onReadReviews={() => {
                const reviewsEl = document.getElementById('marketing-advantage');
                if (reviewsEl) {
                  reviewsEl.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            />
            <Newsletter />
          </>
        )}
      </main>

      <Footer />

      {selectedListing?.category === 'PACKAGE' && packagePreviewActive ? (
        <PackagePreviewModal
          listing={selectedListing}
          onClose={() => {
            setSelectedListing(null);
            setPackagePreviewActive(false);
          }}
          onBook={() => {
            // Success state is presented in modal
          }}
        />
      ) : (
        <DetailModal
          listing={selectedListing}
          onClose={() => {
            setSelectedListing(null);
            setPackagePreviewActive(false);
          }}
          isSaved={selectedListing ? savedListings.some(l => l.id === selectedListing.id) : false}
          onToggleSave={toggleSaveListing}
          onCreatePackage={handleCreatePackageFromListing}
          onCustomTripBuild={handleCustomTripFromListing}
        />
      )}

      {/* Traveler Custom Trip & Package Studio Modal */}
      <CustomTripBuilderModal
        isOpen={showCustomTripBuilderModal}
        availableListings={listings}
        initialListing={customTripInitialListing || undefined}
        onClose={() => {
          setShowCustomTripBuilderModal(false);
          setCustomTripInitialListing(null);
        }}
        onTripCreated={() => {
          // Keep active for review or tracker
        }}
        onOpenTracker={() => setShowCustomTripsTrackerModal(true)}
      />

      {/* Traveler Custom Trips & Package Tracker Modal */}
      <CustomTripsTrackerModal
        isOpen={showCustomTripsTrackerModal}
        onClose={() => setShowCustomTripsTrackerModal(false)}
        onOpenBuilder={() => setShowCustomTripBuilderModal(true)}
        onBookingSuccess={() => {
          loadListings();
        }}
      />

      {/* Admin Quick Package Creator Modal */}
      <PackageCreatorModal
        isOpen={showPackageCreatorModal}
        initialData={packageInitialListing}
        onClose={() => {
          setShowPackageCreatorModal(false);
          setPackageInitialListing(null);
        }}
        onPackageCreated={() => {
          loadListings();
          setShowPackageCreatorModal(false);
          setPackageInitialListing(null);
        }}
      />

      <SavedTripsModal
        isOpen={showSavedModal}
        onClose={() => setShowSavedModal(false)}
        savedListings={savedListings}
        onRemoveSavedTrip={removeSavedListing}
        onSelectListing={(item) => {
          setSelectedListing(item);
          setShowSavedModal(false);
        }}
        onBookListing={(item) => {
          setSelectedListing(item);
          setShowSavedModal(false);
        }}
      />

      <LoginModal />
      <ShortcutsHelpModal isOpen={showShortcutsModal} onClose={() => setShowShortcutsModal(false)} />
      <FloatingContact />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <MainLayout />
        <ToastContainer />
      </AuthProvider>
    </ThemeProvider>
  );
}
