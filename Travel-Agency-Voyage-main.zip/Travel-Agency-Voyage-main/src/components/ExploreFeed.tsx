import React, { useState, useEffect } from 'react';
import { FeedPost } from '../types.ts';
import { Send, Trash2, ShieldCheck, User as UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext.tsx';
import { AuthAudit } from '../services/authAudit.ts';
import { SupabaseDataService } from '../services/supabaseService.ts';

export const ExploreFeed: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [newPostContent, setNewPostContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchPosts = async () => {
    try {
      const supaPosts = await SupabaseDataService.getFeedPosts();
      setPosts(supaPosts || []);
    } catch (err) {
      console.warn('Error fetching feed posts from Supabase:', err);
    }
  };

  useEffect(() => {
    fetchPosts();
    const interval = setInterval(fetchPosts, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleCreatePost = async () => {
    if (!newPostContent.trim() || !user) return;
    setIsSubmitting(true);
    
    try {
      const created = await SupabaseDataService.createFeedPost({
        authorId: user.uid,
        authorName: user.name || 'Administrator',
        authorRole: user.role || 'ADMIN',
        content: newPostContent.trim()
      });

      if (created) {
        setPosts(prev => [created, ...prev]);
        setNewPostContent('');
        AuthAudit.showToast({
          title: 'Post Created',
          message: 'Your announcement was broadcasted successfully to Supabase.',
          type: 'success'
        });
      } else {
        AuthAudit.showToast({
          title: 'Broadcast Error',
          message: 'Could not broadcast announcement to Supabase.',
          type: 'error'
        });
      }
    } catch (supaErr) {
      console.error('Supabase createFeedPost error:', supaErr);
      AuthAudit.showToast({
        title: 'Broadcast Error',
        message: 'Could not connect to broadcast feed.',
        type: 'error'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeletePost = async (id: string) => {
    try {
      await SupabaseDataService.deleteFeedPost(id);
      setPosts(prev => prev.filter(p => p.id !== id));
      AuthAudit.showToast({
        title: 'Post Removed',
        message: 'Post deleted successfully from Supabase.',
        type: 'info'
      });
    } catch (supaErr) {
      console.error('Supabase deleteFeedPost error:', supaErr);
    }
  };

  const canPost = user && ['TECH_ADMIN', 'TECH_SUBADMIN', 'ADMIN'].includes(user.role);

  return (
    <div className="space-y-6 mb-10">
      {canPost && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200/60 dark:border-slate-800 p-5">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2 mb-3">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Broadcast Global Explorer Announcement</span>
          </h3>
          <div className="flex gap-3">
            <input
              type="text"
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="Share an exclusive travel update or announcement with all travelers..."
              className="flex-1 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-xl px-4 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              onKeyDown={(e) => e.key === 'Enter' && handleCreatePost()}
            />
            <button
              onClick={handleCreatePost}
              disabled={isSubmitting || !newPostContent.trim()}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-semibold rounded-xl flex items-center gap-2 transition-colors shadow-sm cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Broadcast</span>
            </button>
          </div>
        </div>
      )}

      {posts.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Live Community Dispatches & Announcements
            </h4>
            <span className="text-[11px] text-slate-400 dark:text-slate-500 font-mono">
              {posts.length} {posts.length === 1 ? 'Dispatch' : 'Dispatches'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {posts.map((post) => (
              <div
                key={post.id}
                className="bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200/60 dark:border-slate-800/80 p-4 shadow-sm hover:border-emerald-500/30 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold text-xs">
                        <UserIcon className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                          {post.authorName}
                          <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                            {post.authorRole}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-400 dark:text-slate-500">
                          {new Date(post.createdAt).toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      </div>
                    </div>

                    {canPost && (
                      <button
                        onClick={() => handleDeletePost(post.id)}
                        className="text-slate-400 hover:text-rose-500 p-1 rounded-lg transition-colors cursor-pointer"
                        title="Delete Announcement"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-sans">
                    {post.content}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
