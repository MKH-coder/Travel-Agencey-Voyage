import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  RefreshCw, 
  CheckCircle2, 
  Shield, 
  Database, 
  ExternalLink, 
  KeyRound, 
  Play, 
  Terminal, 
  AlertTriangle, 
  Check, 
  Eye, 
  EyeOff, 
  ArrowUpRight,
  Layers,
  Activity
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext.tsx';
import { SupabaseSyncService, SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_CONSOLE_URL } from '../services/supabaseSync.ts';
import { SupabaseDataService } from '../services/supabaseService.ts';

export const CloudSyncPanel: React.FC = () => {
  const { styles } = useTheme();

  // Supabase Live Connection States
  const [supabaseUrl] = useState(SUPABASE_URL);
  const [supabaseAnonKey] = useState(SUPABASE_ANON_KEY);
  const [selectedTable, setSelectedTable] = useState('listings');
  const [showKey, setShowKey] = useState(false);

  const [isTestingSupabase, setIsTestingSupabase] = useState(false);
  const [showSqlBlueprint, setShowSqlBlueprint] = useState(false);
  const [sqlCopied, setSqlCopied] = useState(false);
  const [tableData, setTableData] = useState<any[]>([]);
  const [loadingTable, setLoadingTable] = useState(false);

  const [supabaseStatus, setSupabaseStatus] = useState<{
    tested: boolean;
    online: boolean;
    latencyMs?: number;
    message?: string;
  }>({ tested: false, online: true });

  const [tableCounts, setTableCounts] = useState<{
    listings: number;
    profiles: number;
    bookings: number;
    customTrips: number;
    auditLogs: number;
    customPosts: number;
  }>({
    listings: 0,
    profiles: 0,
    bookings: 0,
    customTrips: 0,
    auditLogs: 0,
    customPosts: 0,
  });

  const loadMetrics = async () => {
    try {
      const [listings, profiles, bookings, trips, logs, posts] = await Promise.all([
        SupabaseDataService.getListings().catch(() => []),
        SupabaseDataService.getProfiles().catch(() => []),
        SupabaseDataService.getBookings().catch(() => []),
        SupabaseDataService.getCustomTrips().catch(() => []),
        SupabaseDataService.getAuditLogs().catch(() => []),
        SupabaseDataService.getCustomPosts().catch(() => []),
      ]);

      setTableCounts({
        listings: listings.length,
        profiles: profiles.length,
        bookings: bookings.length,
        customTrips: trips.length,
        auditLogs: logs.length,
        customPosts: posts.length,
      });
    } catch {
      // ignore
    }
  };

  const handleTestSupabase = async () => {
    setIsTestingSupabase(true);
    try {
      const res = await SupabaseSyncService.testConnection();
      setSupabaseStatus({
        tested: true,
        online: res.online,
        latencyMs: res.latencyMs,
        message: res.message,
      });
    } catch (err: any) {
      setSupabaseStatus({
        tested: true,
        online: false,
        message: err?.message || 'Connection test failed',
      });
    } finally {
      setIsTestingSupabase(false);
    }
  };

  const handleFetchTableSample = async (tableName: string) => {
    setLoadingTable(true);
    setSelectedTable(tableName);
    try {
      if (tableName === 'listings') {
        const data = await SupabaseDataService.getListings();
        setTableData(data.slice(0, 5));
      } else if (tableName === 'profiles') {
        const data = await SupabaseDataService.getProfiles();
        setTableData(data.slice(0, 5));
      } else if (tableName === 'bookings') {
        const data = await SupabaseDataService.getBookings();
        setTableData(data.slice(0, 5));
      } else if (tableName === 'audit_logs') {
        const data = await SupabaseDataService.getAuditLogs();
        setTableData(data.slice(0, 5));
      } else if (tableName === 'custom_posts') {
        const data = await SupabaseDataService.getCustomPosts();
        setTableData(data.slice(0, 5));
      } else if (tableName === 'custom_trips') {
        const data = await SupabaseDataService.getCustomTrips();
        setTableData(data.slice(0, 5));
      }
    } catch (err) {
      console.warn('Error fetching table sample:', err);
    } finally {
      setLoadingTable(false);
    }
  };

  useEffect(() => {
    handleTestSupabase();
    loadMetrics();
    handleFetchTableSample('listings');
  }, []);

  const SQL_BLUEPRINT = `-- Voyage Pure Supabase Schema
-- 1. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  phone_number TEXT,
  role TEXT DEFAULT 'USER',
  custom_title TEXT,
  department TEXT,
  custom_post_id TEXT,
  avatar_url TEXT,
  mfa_enabled BOOLEAN DEFAULT FALSE,
  recovery_email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Listings Table
CREATE TABLE IF NOT EXISTS public.listings (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC NOT NULL,
  rating NUMERIC DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  location TEXT,
  country TEXT,
  lat NUMERIC,
  lng NUMERIC,
  description TEXT,
  images TEXT[] DEFAULT '{}',
  status TEXT DEFAULT 'PUBLISHED',
  created_by TEXT,
  created_by_name TEXT,
  approved_by TEXT,
  rejection_reason TEXT,
  tags TEXT[] DEFAULT '{}',
  amenities TEXT[] DEFAULT '{}',
  dining_specialties TEXT[] DEFAULT '{}',
  hotel_perks TEXT[] DEFAULT '{}',
  listing_ids TEXT[] DEFAULT '{}',
  duration TEXT,
  pinned BOOLEAN DEFAULT FALSE,
  pinned_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Bookings Table
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT REFERENCES public.listings(id) ON DELETE CASCADE,
  user_id TEXT,
  check_in_date DATE NOT NULL,
  check_out_date DATE,
  guests INTEGER DEFAULT 1,
  total_price NUMERIC NOT NULL,
  status TEXT DEFAULT 'CONFIRMED',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Custom Posts Table
CREATE TABLE IF NOT EXISTS public.custom_posts (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  department TEXT,
  color TEXT DEFAULT '#3B82F6',
  badge_label TEXT,
  privileges TEXT[] DEFAULT '{}',
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Audit Logs Table
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action TEXT NOT NULL,
  performed_by_email TEXT,
  target_id TEXT,
  target_type TEXT,
  ip_address TEXT DEFAULT '127.0.0.1',
  details JSONB DEFAULT '{}'::jsonb,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Custom Trips Table
CREATE TABLE IF NOT EXISTS public.custom_trips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  trip_title TEXT NOT NULL,
  destination TEXT,
  country TEXT,
  travel_style TEXT,
  budget_tier TEXT,
  start_date DATE,
  end_date DATE,
  duration_days INTEGER,
  adults INTEGER DEFAULT 1,
  children INTEGER DEFAULT 0,
  selected_listing_ids TEXT[] DEFAULT '{}',
  inclusions TEXT[] DEFAULT '{}',
  special_requests TEXT,
  dietary_preferences TEXT[] DEFAULT '{}',
  estimated_total NUMERIC,
  bundle_discount NUMERIC DEFAULT 0,
  final_price NUMERIC,
  status TEXT DEFAULT 'SUBMITTED',
  itinerary JSONB DEFAULT '[]'::jsonb,
  concierge_notes TEXT,
  quoted_price NUMERIC,
  converted_to_package_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Reviews Table
CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT REFERENCES public.listings(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  is_reported BOOLEAN DEFAULT FALSE,
  report_reason TEXT,
  reported_by TEXT,
  moderation_status TEXT DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Feed Posts Table
CREATE TABLE IF NOT EXISTS public.feed_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id TEXT NOT NULL,
  author_name TEXT NOT NULL,
  author_role TEXT DEFAULT 'EXPLORER',
  content TEXT NOT NULL,
  pinned BOOLEAN DEFAULT FALSE,
  likes INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Active Sessions Table
CREATE TABLE IF NOT EXISTS public.active_sessions (
  uid TEXT PRIMARY KEY,
  name TEXT,
  email TEXT,
  role TEXT,
  custom_title TEXT,
  ip_address TEXT,
  device TEXT,
  browser TEXT,
  os TEXT,
  status TEXT DEFAULT 'ONLINE',
  last_heartbeat TIMESTAMPTZ DEFAULT NOW(),
  login_time TIMESTAMPTZ DEFAULT NOW()
);`;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-500/20 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                Single Source of Truth
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2.5">
              <Database className="w-7 h-7 text-emerald-400" />
              <span>Supabase Cloud Architecture</span>
            </h2>
            <p className="text-sm text-slate-400 max-w-2xl">
              All platform data, authentication, storage, and telemetry run exclusively on Supabase PostgreSQL.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                handleTestSupabase();
                loadMetrics();
              }}
              disabled={isTestingSupabase}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-700 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isTestingSupabase ? 'animate-spin' : ''}`} />
              <span>Ping Health</span>
            </button>

            <a
              href={SUPABASE_CONSOLE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-emerald-900/30 cursor-pointer"
            >
              <span>Dashboard</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Live Metrics Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Listings</div>
            <div className="text-lg font-bold text-emerald-400">{tableCounts.listings}</div>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Profiles</div>
            <div className="text-lg font-bold text-sky-400">{tableCounts.profiles}</div>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Bookings</div>
            <div className="text-lg font-bold text-amber-400">{tableCounts.bookings}</div>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Custom Trips</div>
            <div className="text-lg font-bold text-purple-400">{tableCounts.customTrips}</div>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Audit Logs</div>
            <div className="text-lg font-bold text-rose-400">{tableCounts.auditLogs}</div>
          </div>
          <div className="bg-slate-900/60 rounded-xl p-3 border border-slate-800">
            <div className="text-[10px] uppercase font-bold text-slate-400">Custom Posts</div>
            <div className="text-lg font-bold text-teal-400">{tableCounts.customPosts}</div>
          </div>
        </div>
      </div>

      {/* Connection & Credentials */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className={`p-6 rounded-3xl border ${styles.border} ${styles.cardBg} space-y-4 shadow-sm`}>
          <div className="flex items-center justify-between">
            <h3 className={`text-base font-bold ${styles.textPrimary} flex items-center gap-2`}>
              <Cloud className="w-5 h-5 text-emerald-500" />
              <span>Project Configuration</span>
            </h3>
            <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${
              supabaseStatus.online
                ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                : 'bg-rose-500/10 text-rose-500 border border-rose-500/20'
            }`}>
              {supabaseStatus.online ? 'Online' : 'Unreachable'}
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">API Endpoint URL</label>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 font-mono text-xs text-slate-200 select-all overflow-x-auto">
                {supabaseUrl}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-400">Publishable / Anon API Key</label>
                <button
                  onClick={() => setShowKey(!showKey)}
                  className="text-xs text-emerald-500 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showKey ? 'Hide' : 'Reveal'}</span>
                </button>
              </div>
              <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 font-mono text-xs text-slate-200 select-all overflow-x-auto">
                {showKey ? supabaseAnonKey : '•'.repeat(40)}
              </div>
            </div>

            {supabaseStatus.tested && (
              <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                supabaseStatus.online
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}>
                {supabaseStatus.online ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
                <span>{supabaseStatus.message}</span>
              </div>
            )}
          </div>
        </div>

        {/* Database Tables Explorer */}
        <div className={`p-6 rounded-3xl border ${styles.border} ${styles.cardBg} space-y-4 shadow-sm flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className={`text-base font-bold ${styles.textPrimary} flex items-center gap-2`}>
                <Layers className="w-5 h-5 text-sky-500" />
                <span>PostgreSQL Tables</span>
              </h3>
              <button
                onClick={() => setShowSqlBlueprint(!showSqlBlueprint)}
                className="text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>{showSqlBlueprint ? 'Hide DDL' : 'View SQL Schema'}</span>
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              Click a table to inspect live records from your Supabase PostgreSQL cluster:
            </p>

            <div className="grid grid-cols-3 gap-2">
              {[
                { name: 'listings', count: tableCounts.listings },
                { name: 'profiles', count: tableCounts.profiles },
                { name: 'bookings', count: tableCounts.bookings },
                { name: 'custom_trips', count: tableCounts.customTrips },
                { name: 'audit_logs', count: tableCounts.auditLogs },
                { name: 'custom_posts', count: tableCounts.customPosts },
              ].map(tbl => (
                <button
                  key={tbl.name}
                  onClick={() => handleFetchTableSample(tbl.name)}
                  className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedTable === tbl.name
                      ? 'bg-emerald-500/10 border-emerald-500 text-emerald-400'
                      : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[11px] font-mono font-bold truncate">{tbl.name}</div>
                  <div className="text-[10px] text-slate-500">{tbl.count} rows</div>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80">
            <div className="text-xs text-slate-400 flex items-center justify-between">
              <span>Selected table: <strong className="font-mono text-slate-200">{selectedTable}</strong></span>
              <span className="text-[10px] text-emerald-400 font-mono">Row-Level Security (RLS) Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* SQL Schema Blueprint Display */}
      {showSqlBlueprint && (
        <div className={`p-6 rounded-3xl border ${styles.border} ${styles.cardBg} space-y-3 shadow-sm`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-emerald-400" />
              <h3 className={`text-base font-bold ${styles.textPrimary}`}>Supabase PostgreSQL Schema (DDL)</h3>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText(SQL_BLUEPRINT);
                setSqlCopied(true);
                setTimeout(() => setSqlCopied(false), 2000);
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {sqlCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Layers className="w-3.5 h-3.5" />}
              <span>{sqlCopied ? 'Copied!' : 'Copy SQL Script'}</span>
            </button>
          </div>
          <pre className="p-4 rounded-2xl bg-slate-950 font-mono text-[11px] text-emerald-400/90 overflow-x-auto max-h-72 border border-slate-800 leading-relaxed">
            {SQL_BLUEPRINT}
          </pre>
        </div>
      )}

      {/* Live Table Records Sample */}
      <div className={`p-6 rounded-3xl border ${styles.border} ${styles.cardBg} space-y-4 shadow-sm`}>
        <div className="flex items-center justify-between">
          <h3 className={`text-base font-bold ${styles.textPrimary} flex items-center gap-2`}>
            <Activity className="w-5 h-5 text-emerald-500" />
            <span>Live Records Sample (<span className="font-mono text-emerald-400">{selectedTable}</span>)</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {loadingTable ? 'Loading...' : `${tableData.length} records retrieved`}
          </span>
        </div>

        {tableData.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            No records found or table is currently empty in Supabase.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <pre className="p-4 rounded-2xl bg-slate-950 font-mono text-[11px] text-slate-300 max-h-64 border border-slate-800 overflow-y-auto">
              {JSON.stringify(tableData, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
};
