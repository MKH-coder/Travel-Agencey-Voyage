// Deprecated - Replaced completely with SupabaseConsoleModal
export {};
