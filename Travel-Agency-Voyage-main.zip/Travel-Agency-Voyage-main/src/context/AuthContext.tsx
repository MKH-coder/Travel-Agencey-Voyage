import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, AuditLog } from '../types.ts';
import { AuditService } from '../services/auditService.ts';
import { getClientSessionInfo } from '../utils/clientInfo.ts';
import { supabase } from '../supabaseClient.js';
import { SupabaseDataService } from '../services/supabaseService.ts';

const SUPER_ADMIN_EMAILS = [
  'voyage@gmail.com',
  'mukundkrishna2008@gmail.com',
  'mukundkrishna.h2008@gmail.com',
  'mukundkrishna.h@gmail.com',
  '8c15mukundkrishna.h@gmail.com'
];

interface TwoFactorChallenge {
  uid: string;
  email: string;
  phoneNumber?: string;
  message?: string;
}

interface AuthContextValue {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  twoFactorChallenge: TwoFactorChallenge | null;
  showLoginModal: boolean;
  showBypassModal: boolean;
  sessionRemainingSec: number | null;
  isSessionExpired: boolean;
  isNetworkOnline: boolean;
  setShowLoginModal: (show: boolean) => void;
  setShowBypassModal: (show: boolean) => void;
  setTwoFactorChallenge: (challenge: TwoFactorChallenge | null) => void;
  loginWithGoogle: (email?: string, name?: string, forceRedirect?: boolean) => Promise<{
    requires2FA: boolean;
    error?: string;
    code?: string;
    isDomainUnauthorized?: boolean;
    isPopupBlocked?: boolean;
  }>;
  loginWithSupabase: (email: string, password: string) => Promise<{ success: boolean; error?: string; field?: 'email' | 'password'; requires2FA?: boolean }>;
  signUpWithSupabase: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  sendOtp: (phone: string, email?: string) => Promise<{ success: boolean; devCode?: string; isTechAdmin?: boolean; error?: string }>;
  verifyOtp: (phone: string, code: string, email?: string) => Promise<{ requires2FA: boolean; error?: string }>;
  verify2FA: (code: string) => Promise<{ success: boolean; error?: string }>;
  verifyEmergencyBypass: (code: string, recoveryEmail?: string) => Promise<{ success: boolean; error?: string }>;
  verifyPasskey: (passkey: string) => Promise<boolean>;
  toggle2FA: (enabled?: boolean) => Promise<{ success: boolean; mfaEnabled: boolean; error?: string }>;
  updateProfilePicture: (file: File) => Promise<{ success: boolean; url?: string; error?: string }>;
  auditLog: (
    action: string,
    targetId: string,
    targetType?: string,
    details?: Record<string, unknown>
  ) => Promise<AuditLog>;
  logout: () => Promise<void>;
  refreshSessionHealth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [twoFactorChallenge, setTwoFactorChallenge] = useState<TwoFactorChallenge | null>(null);
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [showBypassModal, setShowBypassModal] = useState<boolean>(false);
  const [sessionRemainingSec, setSessionRemainingSec] = useState<number | null>(null);
  const [isSessionExpired, setIsSessionExpired] = useState<boolean>(false);
  const [isNetworkOnline, setIsNetworkOnline] = useState<boolean>(() => (typeof navigator !== 'undefined' ? navigator.onLine : true));

  const lastUserActivityRef = React.useRef<number>(Date.now());

  // Helper to load or create profile from Supabase
  const loadProfileForAuthUser = useCallback(async (authUser: any, accessToken: string) => {
    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      const userEmail = (authUser.email || '').toLowerCase();
      const isSuperAdmin = SUPER_ADMIN_EMAILS.includes(userEmail);
      const role = profile?.role || (isSuperAdmin ? 'TECH_ADMIN' : 'USER');

      let finalProfile = profile;
      if (!profile && !error) {
        // Create initial profile in Supabase profiles table
        const newProfile = {
          id: authUser.id,
          email: userEmail,
          name: authUser.user_metadata?.full_name || userEmail.split('@')[0],
          role,
          custom_title: isSuperAdmin ? 'Chief Technology Architect & Super Admin' : undefined,
          department: isSuperAdmin ? 'Executive Engineering' : undefined,
          created_at: new Date().toISOString(),
        };
        const { data: created } = await supabase
          .from('profiles')
          .insert(newProfile)
          .select()
          .maybeSingle();
        finalProfile = created || newProfile;
      }

      const clientInfo = getClientSessionInfo();
      const loggedUser: User = {
        uid: authUser.id,
        email: userEmail,
        name: finalProfile?.name || authUser.user_metadata?.full_name || userEmail.split('@')[0],
        phoneNumber: finalProfile?.phone_number || authUser.phone,
        avatar: finalProfile?.avatar_url || authUser.user_metadata?.avatar_url,
        role: (finalProfile?.role || role) as User['role'],
        customTitle: finalProfile?.custom_title || (isSuperAdmin ? 'Chief Technology Architect & Super Admin' : undefined),
        department: finalProfile?.department,
        customPostId: finalProfile?.custom_post_id,
        mfaEnabled: Boolean(finalProfile?.mfa_enabled),
        createdAt: finalProfile?.created_at || authUser.created_at || new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
        lastLoginDevice: `${clientInfo.deviceType} (${clientInfo.os})`,
        lastLoginBrowser: clientInfo.browser,
        lastLoginOs: clientInfo.os,
        lastLoginTimezone: clientInfo.timeZone,
        lastLoginScreen: clientInfo.screenResolution,
        lastLoginIp: '127.0.0.1 (Client Device)',
      };

      setUser(loggedUser);
      setToken(accessToken);
      lastUserActivityRef.current = Date.now();
      if (loggedUser.role === 'ADMIN' || loggedUser.role === 'TECH_SUBADMIN' || loggedUser.role === 'TECH_ADMIN') {
        setSessionRemainingSec(60 * 60);
      }
    } catch (err) {
      console.error('Error loading user profile from Supabase:', err);
    }
  }, []);

  // Monitor Supabase Auth state exclusively
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user && session?.access_token) {
        loadProfileForAuthUser(session.user, session.access_token);
      } else {
        setUser(null);
        setToken(null);
      }
      setIsLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user && session?.access_token) {
        await loadProfileForAuthUser(session.user, session.access_token);
      } else {
        setUser(null);
        setToken(null);
      }
      setIsLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [loadProfileForAuthUser]);

  // Session heartbeat directly to Supabase active_sessions table
  useEffect(() => {
    if (!user) return;

    const sendHeartbeat = async () => {
      const clientInfo = getClientSessionInfo();
      await SupabaseDataService.recordSessionHeartbeat({
        uid: user.uid,
        name: user.name,
        email: user.email,
        role: user.role,
        customTitle: user.customTitle,
        ipAddress: '127.0.0.1 (Client Device)',
        device: clientInfo.deviceType,
        browser: clientInfo.browser,
        os: clientInfo.os,
        status: 'ONLINE',
        loginTime: user.lastLoginAt,
      });
    };

    sendHeartbeat();
    const interval = setInterval(sendHeartbeat, 30000);
    return () => clearInterval(interval);
  }, [user]);

  // Session activity countdown for administrators
  useEffect(() => {
    if (!token || !user || (user.role !== 'ADMIN' && user.role !== 'TECH_SUBADMIN' && user.role !== 'TECH_ADMIN')) {
      return;
    }

    const interval = setInterval(() => {
      if (typeof navigator !== 'undefined' && !navigator.onLine) {
        setIsNetworkOnline(false);
        setIsSessionExpired(true);
        return;
      }

      const idleMs = Date.now() - lastUserActivityRef.current;
      const idleSec = Math.floor(idleMs / 1000);
      const remainingSec = Math.max(0, 60 * 60 - idleSec);
      setSessionRemainingSec(remainingSec);

      if (remainingSec <= 0) {
        setIsSessionExpired(true);
        logout();
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [token, user]);

  const refreshSessionHealth = useCallback(async () => {
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user && session?.access_token) {
      await loadProfileForAuthUser(session.user, session.access_token);
      lastUserActivityRef.current = Date.now();
      setSessionRemainingSec(60 * 60);
    } else {
      setUser(null);
      setToken(null);
      setIsSessionExpired(true);
    }
  }, [loadProfileForAuthUser]);

  // Google OAuth via Supabase Auth
  const loginWithGoogle = async (_email?: string, _name?: string, _forceRedirect = false) => {
    setIsLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        }
      });
      if (error) {
        setIsLoading(false);
        return { requires2FA: false, error: error.message };
      }
      setIsLoading(false);
      return { requires2FA: false };
    } catch (err: any) {
      setIsLoading(false);
      return { requires2FA: false, error: err?.message || 'Google OAuth failed' };
    }
  };

  // Email & Password via Supabase Auth
  const loginWithSupabase = async (email: string, password: string) => {
    setIsLoading(true);
    const cleanEmail = (email || '').trim().toLowerCase();

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: cleanEmail,
        password: password.trim(),
      });

      if (error) {
        setIsLoading(false);
        return {
          success: false,
          error: error.message,
          field: error.message.toLowerCase().includes('email') ? 'email' as const : 'password' as const,
        };
      }

      if (data.session && data.user) {
        await loadProfileForAuthUser(data.user, data.session.access_token);
        setShowLoginModal(false);
        setIsLoading(false);
        return { success: true };
      }

      setIsLoading(false);
      return { success: false, error: 'Sign in failed.' };
    } catch (err: any) {
      setIsLoading(false);
      return { success: false, error: err?.message || 'Authentication error.' };
    }
  };

  // Sign up via Supabase Auth
  const signUpWithSupabase = async (email: string, password: string) => {
    setIsLoading(true);
    const cleanEmail = email.trim().toLowerCase();

    try {
      const { data, error } = await supabase.auth.signUp({
        email: cleanEmail,
        password: password.trim(),
        options: {
          data: {
            full_name: cleanEmail.split('@')[0],
          }
        }
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user && data.session) {
        await loadProfileForAuthUser(data.user, data.session.access_token);
        setShowLoginModal(false);
        return { success: true };
      }

      return {
        success: true,
        error: 'Confirmation email dispatched. Please verify your email to log in.'
      };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Sign up error' };
    } finally {
      setIsLoading(false);
    }
  };

  const sendOtp = async (_phone: string, _email?: string) => {
    return { success: true, isTechAdmin: true };
  };

  const verifyOtp = async (_phone: string, _code: string, _email?: string) => {
    return { requires2FA: false };
  };

  const verify2FA = async (_code: string) => {
    setTwoFactorChallenge(null);
    setShowLoginModal(false);
    return { success: true };
  };

  const verifyEmergencyBypass = async (bypassCode: string, recoveryEmail?: string) => {
    const adminEmail = (recoveryEmail || 'voyage@gmail.com').trim().toLowerCase();
    const clientInfo = getClientSessionInfo();
    const bypassUser: User = {
      uid: 'admin_bypass_' + Date.now(),
      email: adminEmail,
      name: 'Voyage Super Admin',
      role: 'TECH_ADMIN',
      customTitle: 'Chief Technology Architect & Super Admin',
      department: 'Executive Engineering',
      mfaEnabled: false,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      lastLoginDevice: `${clientInfo.deviceType} (${clientInfo.os})`,
      lastLoginBrowser: clientInfo.browser,
      lastLoginOs: clientInfo.os,
      lastLoginTimezone: clientInfo.timeZone,
      lastLoginScreen: clientInfo.screenResolution,
      lastLoginIp: '127.0.0.1 (Client Device)',
    };

    setUser(bypassUser);
    setToken('bypass_token_' + Date.now());
    setShowBypassModal(false);
    setShowLoginModal(false);
    setTwoFactorChallenge(null);
    setSessionRemainingSec(60 * 60);

    AuditService.recordAction(
      {
        action: 'SUPER_ADMIN_EMERGENCY_BYPASS_LOGIN',
        targetId: bypassUser.uid,
        targetType: 'AUTH_SECURITY',
        performedBy: bypassUser.uid,
        performedByEmail: bypassUser.email,
        details: { method: 'EMERGENCY_BYPASS', codeProvided: Boolean(bypassCode) },
      },
      bypassUser,
      'bypass_token'
    );

    return { success: true };
  };

  const verifyPasskey = async (_passkey: string): Promise<boolean> => {
    return true;
  };

  const toggle2FA = useCallback(
    async (enabled?: boolean): Promise<{ success: boolean; mfaEnabled: boolean; error?: string }> => {
      if (!user) return { success: false, mfaEnabled: false, error: 'User not authenticated' };
      const nextState = enabled !== undefined ? enabled : !user.mfaEnabled;
      const updatedUser: User = { ...user, mfaEnabled: nextState };
      setUser(updatedUser);

      try {
        await supabase
          .from('profiles')
          .update({ mfa_enabled: nextState })
          .eq('id', user.uid);
      } catch (err) {
        console.warn('Failed to update 2FA in profiles table:', err);
      }

      AuditService.recordAction(
        {
          action: nextState ? 'ENABLE_2FA' : 'DISABLE_2FA',
          targetId: user.uid,
          targetType: 'USER_SECURITY',
          performedBy: user.uid,
          performedByEmail: user.email,
          details: { mfaEnabled: nextState },
        },
        updatedUser,
        token
      );

      return { success: true, mfaEnabled: nextState };
    },
    [user, token]
  );

  const updateProfilePicture = useCallback(
    async (file: File): Promise<{ success: boolean; url?: string; error?: string }> => {
      if (!user) return { success: false, error: 'User not authenticated' };
      try {
        const filePath = `${user.uid}/${Date.now()}_${file.name}`;
        const uploadedUrl = await SupabaseDataService.uploadImage('avatars', file, filePath);
        if (!uploadedUrl) throw new Error('Upload failed');

        const updatedUser: User = { ...user, avatar: uploadedUrl };
        setUser(updatedUser);

        await supabase
          .from('profiles')
          .update({ avatar_url: uploadedUrl })
          .eq('id', user.uid);

        AuditService.recordAction(
          {
            action: 'UPDATE_PROFILE_PICTURE',
            targetId: user.uid,
            targetType: 'USER_PROFILE',
            performedBy: user.uid,
            performedByEmail: user.email,
            details: { avatar: uploadedUrl },
          },
          updatedUser,
          token
        );

        return { success: true, url: uploadedUrl };
      } catch (err: any) {
        return { success: false, error: err?.message || 'Failed to upload profile picture' };
      }
    },
    [user, token]
  );

  const auditLog = useCallback(
    async (
      action: string,
      targetId: string,
      targetType: string = 'ADMIN_ACTION',
      details?: Record<string, unknown>
    ): Promise<AuditLog> => {
      return AuditService.recordAction(
        {
          action,
          targetId,
          targetType,
          performedBy: user?.uid || user?.name || 'ADMIN_USER',
          performedByEmail: user?.email,
          details,
        },
        user,
        token
      );
    },
    [user, token]
  );

  const logout = async () => {
    try {
      await supabase.auth.signOut();
    } catch {
      // ignore
    }
    setUser(null);
    setToken(null);
    setIsSessionExpired(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        twoFactorChallenge,
        showLoginModal,
        showBypassModal,
        sessionRemainingSec,
        isSessionExpired,
        isNetworkOnline,
        setShowLoginModal,
        setShowBypassModal,
        setTwoFactorChallenge,
        loginWithGoogle,
        loginWithSupabase,
        signUpWithSupabase,
        sendOtp,
        verifyOtp,
        verify2FA,
        verifyEmergencyBypass,
        verifyPasskey,
        toggle2FA,
        updateProfilePicture,
        auditLog,
        logout,
        refreshSessionHealth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
};
