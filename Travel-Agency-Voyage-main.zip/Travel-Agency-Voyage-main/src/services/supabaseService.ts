import { supabase } from '../supabaseClient.js';
import { 
  Listing, 
  User, 
  UserRole,
  CustomPost, 
  PostPrivilege,
  AuditLog, 
  Booking, 
  PriceAlert, 
  Review, 
  CustomTripRequest, 
  FeedPost,
  ListingStatus 
} from '../types.ts';

// Helper to map DB snake_case to frontend Listing shape
export function mapDbListingToFrontend(row: Record<string, any>): Listing {
  return {
    id: row.id,
    title: row.title || 'Untitled Experience',
    category: row.category || 'PLACE',
    price: Number(row.price || 0),
    rating: Number(row.rating || 5),
    reviewCount: Number(row.review_count || 0),
    location: row.location || '',
    country: row.country || '',
    coordinates: (row.lat !== undefined && row.lng !== undefined && row.lat !== null && row.lng !== null)
      ? { lat: Number(row.lat), lng: Number(row.lng) }
      : undefined,
    description: row.description || '',
    images: row.images || [],
    status: (row.status || 'PUBLISHED') as ListingStatus,
    createdBy: row.created_by || 'SYSTEM',
    createdByName: row.created_by_name,
    approvedBy: row.approved_by,
    rejectionReason: row.rejection_reason,
    tags: row.tags || [],
    amenities: row.amenities || [],
    diningSpecialties: row.dining_specialties || [],
    hotelPerks: row.hotel_perks || [],
    listingIds: row.listing_ids || [],
    duration: row.duration,
    pinned: Boolean(row.pinned),
    pinnedAt: row.pinned_at,
    timestamps: {
      createdAt: row.created_at || new Date().toISOString(),
      updatedAt: row.updated_at || new Date().toISOString(),
      submittedAt: row.created_at,
      approvedAt: row.approved_at,
    },
  };
}

// Helper to map frontend Listing shape to DB snake_case columns
export function mapFrontendListingToDb(listing: Partial<Listing>): Record<string, any> {
  const row: Record<string, any> = {};
  if (listing.id) row.id = listing.id;
  if (listing.title !== undefined) row.title = listing.title;
  if (listing.category !== undefined) row.category = listing.category;
  if (listing.price !== undefined) row.price = listing.price;
  if (listing.rating !== undefined) row.rating = listing.rating;
  if (listing.reviewCount !== undefined) row.review_count = listing.reviewCount;
  if (listing.location !== undefined) row.location = listing.location;
  if (listing.country !== undefined) row.country = listing.country;
  if (listing.coordinates) {
    row.lat = listing.coordinates.lat;
    row.lng = listing.coordinates.lng;
  }
  if (listing.description !== undefined) row.description = listing.description;
  if (listing.images !== undefined) row.images = listing.images;
  if (listing.status !== undefined) row.status = listing.status;
  if (listing.createdBy !== undefined) row.created_by = listing.createdBy;
  if (listing.createdByName !== undefined) row.created_by_name = listing.createdByName;
  if (listing.approvedBy !== undefined) row.approved_by = listing.approvedBy;
  if (listing.rejectionReason !== undefined) row.rejection_reason = listing.rejectionReason;
  if (listing.tags !== undefined) row.tags = listing.tags;
  if (listing.amenities !== undefined) row.amenities = listing.amenities;
  if (listing.diningSpecialties !== undefined) row.dining_specialties = listing.diningSpecialties;
  if (listing.hotelPerks !== undefined) row.hotel_perks = listing.hotelPerks;
  if (listing.listingIds !== undefined) row.listing_ids = listing.listingIds;
  if (listing.duration !== undefined) row.duration = listing.duration;
  if (listing.pinned !== undefined) row.pinned = listing.pinned;
  if (listing.pinnedAt !== undefined) row.pinned_at = listing.pinnedAt;
  return row;
}

export const SupabaseDataService = {
  // ==================== LISTINGS ====================
  async getListings(): Promise<Listing[]> {
    try {
      const { data, error } = await supabase
        .from('listings')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.warn('Supabase getListings error:', error.message);
        return [];
      }

      if (!data || data.length === 0) {
        return [];
      }

      return data.map(mapDbListingToFrontend);
    } catch (err) {
      console.warn('Supabase getListings fetch failed:', err);
      return [];
    }
  },

  async createListing(listingData: Partial<Listing>): Promise<Listing | null> {
    const row = mapFrontendListingToDb(listingData);
    const { data, error } = await supabase
      .from('listings')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('Supabase createListing error:', error);
      throw error;
    }
    return data ? mapDbListingToFrontend(data) : null;
  },

  async updateListing(id: string, updates: Partial<Listing>): Promise<Listing | null> {
    const row = mapFrontendListingToDb(updates);
    row.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from('listings')
      .update(row)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Supabase updateListing error:', error);
      throw error;
    }
    return data ? mapDbListingToFrontend(data) : null;
  },

  async updateListingStatus(
    id: string,
    status: ListingStatus,
    approvedBy?: string,
    rejectionReason?: string
  ): Promise<Listing | null> {
    const updates: Record<string, any> = {
      status,
      updated_at: new Date().toISOString(),
    };
    if (approvedBy) {
      updates.approved_by = approvedBy;
      updates.approved_at = new Date().toISOString();
    }
    if (rejectionReason !== undefined) {
      updates.rejection_reason = rejectionReason;
    }

    const { data, error } = await supabase
      .from('listings')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Supabase updateListingStatus error:', error);
      throw error;
    }
    return data ? mapDbListingToFrontend(data) : null;
  },

  async togglePinListing(id: string, pinned: boolean): Promise<Listing | null> {
    const updates = {
      pinned,
      pinned_at: pinned ? new Date().toISOString() : null,
      updated_at: new Date().toISOString(),
    };

    const { data, error } = await supabase
      .from('listings')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Supabase togglePinListing error:', error);
      throw error;
    }
    return data ? mapDbListingToFrontend(data) : null;
  },

  async deleteListing(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('listings')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deleteListing error:', error);
      throw error;
    }
    return true;
  },

  async deleteListingsBulk(ids: string[]): Promise<boolean> {
    const { error } = await supabase
      .from('listings')
      .delete()
      .in('id', ids);

    if (error) {
      console.error('Supabase deleteListingsBulk error:', error);
      throw error;
    }
    return true;
  },

  async deleteAllListings(): Promise<boolean> {
    const { error } = await supabase
      .from('listings')
      .delete()
      .neq('id', '');

    if (error) {
      console.error('Supabase deleteAllListings error:', error);
      throw error;
    }
    return true;
  },

  // ==================== BOOKINGS ====================
  async getBookings(): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        id,
        listing_id,
        user_id,
        check_in_date,
        check_out_date,
        guests,
        total_price,
        status,
        created_at,
        listings (
          title,
          category,
          images
        ),
        profiles (
          email
        )
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getBookings error:', error);
      return [];
    }

    return (data || []).map((b: any) => ({
      id: b.id,
      listingId: b.listing_id,
      listingTitle: b.listings?.title || 'Destination Booking',
      listingCategory: b.listings?.category || 'HOTEL',
      listingImage: b.listings?.images?.[0] || '',
      userId: b.user_id,
      userEmail: b.profiles?.email || '',
      checkInDate: b.check_in_date,
      checkOutDate: b.check_out_date,
      guests: b.guests,
      totalPrice: Number(b.total_price),
      status: b.status,
      createdAt: b.created_at,
    }));
  },

  async createBooking(booking: Omit<Booking, 'id' | 'createdAt'>): Promise<Booking | null> {
    const isUuid = (val?: string) => Boolean(val && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(val));

    const checkIn = booking.checkInDate && booking.checkInDate.includes('-')
      ? booking.checkInDate.split('T')[0]
      : new Date().toISOString().split('T')[0];

    const checkOut = booking.checkOutDate && booking.checkOutDate.includes('-')
      ? booking.checkOutDate.split('T')[0]
      : undefined;

    const payload: Record<string, any> = {
      listing_id: String(booking.listingId),
      check_in_date: checkIn,
      guests: Number(booking.guests) || 1,
      total_price: Number(booking.totalPrice) || 0,
      status: booking.status || 'CONFIRMED',
    };

    if (checkOut) {
      payload.check_out_date = checkOut;
    }

    if (booking.userId) {
      payload.user_id = booking.userId;
    }

    let { data, error } = await supabase
      .from('bookings')
      .insert(payload)
      .select()
      .maybeSingle();

    // If failed due to user_id UUID constraint, retry with null user_id
    if (error && error.message && error.message.includes('uuid') && payload.user_id && !isUuid(payload.user_id)) {
      console.warn('Retrying booking without non-UUID user_id:', payload.user_id);
      delete payload.user_id;
      const retry = await supabase
        .from('bookings')
        .insert(payload)
        .select()
        .maybeSingle();
      data = retry.data;
      error = retry.error;
    }

    if (error) {
      console.error('Supabase createBooking error:', error);
      throw error;
    }

    return {
      ...booking,
      id: data?.id || `bk_${Date.now()}`,
      createdAt: data?.created_at || new Date().toISOString(),
    };
  },

  // ==================== SAVED TRIPS (BOOKMARKS) ====================
  async getSavedTrips(userId?: string): Promise<Listing[]> {
    if (!userId) return [];
    const { data, error } = await supabase
      .from('saved_trips')
      .select(`
        listing_id,
        listings (*)
      `)
      .eq('user_id', userId);

    if (error) {
      console.warn('Supabase getSavedTrips error:', error);
      return [];
    }

    return (data || [])
      .map((row: any) => row.listings ? mapDbListingToFrontend(row.listings) : null)
      .filter((l): l is Listing => l !== null);
  },

  async saveTrip(userId: string, listingId: string): Promise<boolean> {
    const { error } = await supabase
      .from('saved_trips')
      .upsert({ user_id: userId, listing_id: listingId });

    if (error) {
      console.error('Supabase saveTrip error:', error);
      return false;
    }
    return true;
  },

  async removeSavedTrip(userId: string, listingId: string): Promise<boolean> {
    const { error } = await supabase
      .from('saved_trips')
      .delete()
      .eq('user_id', userId)
      .eq('listing_id', listingId);

    if (error) {
      console.error('Supabase removeSavedTrip error:', error);
      return false;
    }
    return true;
  },

  // ==================== REVIEWS ====================
  async getReviews(listingId: string): Promise<Review[]> {
    const { data, error } = await supabase
      .from('reviews')
      .select(`
        id,
        listing_id,
        user_id,
        rating,
        comment,
        is_reported,
        report_reason,
        moderation_status,
        created_at,
        profiles (
          name,
          email,
          avatar_url
        )
      `)
      .eq('listing_id', listingId)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getReviews error:', error);
      return [];
    }

    return (data || []).map((r: any) => ({
      id: r.id,
      listingId: r.listing_id,
      userId: r.user_id,
      userName: r.profiles?.name || 'Traveler',
      userEmail: r.profiles?.email || '',
      userAvatar: r.profiles?.avatar_url,
      rating: r.rating,
      comment: r.comment,
      isReported: r.is_reported,
      reportReason: r.report_reason,
      moderationStatus: r.moderation_status,
      createdAt: r.created_at,
    }));
  },

  async createReview(review: Omit<Review, 'id' | 'createdAt'>): Promise<Review | null> {
    const { data, error } = await supabase
      .from('reviews')
      .insert({
        listing_id: review.listingId,
        user_id: review.userId,
        rating: review.rating,
        comment: review.comment,
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase createReview error:', error);
      throw error;
    }

    return {
      ...review,
      id: data.id,
      createdAt: data.created_at,
    };
  },

  async deleteReview(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('reviews')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deleteReview error:', error);
      return false;
    }
    return true;
  },

  async reportReview(id: string, reason: string, reporterEmail: string, reporterId: string, listingTitle?: string): Promise<boolean> {
    const { error } = await supabase
      .from('reviews')
      .update({
        is_reported: true,
        report_reason: reason,
        reported_by: reporterId,
        reported_by_email: reporterEmail,
        reported_at: new Date().toISOString(),
        moderation_status: 'PENDING',
      })
      .eq('id', id);

    if (error) {
      console.error('Supabase reportReview error:', error);
      return false;
    }
    return true;
  },

  // ==================== CUSTOM TRIPS ====================
  async getCustomTrips(userEmail?: string): Promise<CustomTripRequest[]> {
    let query = supabase
      .from('custom_trips')
      .select('*')
      .order('created_at', { ascending: false });

    const { data, error } = await query;
    if (error) {
      console.warn('Supabase getCustomTrips error:', error);
      return [];
    }

    return (data || []).map((t: any) => ({
      id: t.id,
      userId: t.user_id,
      userEmail: t.user_email || userEmail || '',
      userName: t.user_name || 'Traveler',
      tripTitle: t.trip_title,
      destination: t.destination,
      country: t.country,
      travelStyle: t.travel_style,
      budgetTier: t.budget_tier,
      startDate: t.start_date,
      endDate: t.end_date,
      durationDays: t.duration_days,
      adults: t.adults,
      children: t.children,
      selectedListingIds: t.selected_listing_ids || [],
      itinerary: t.itinerary || [],
      inclusions: t.inclusions || [],
      specialRequests: t.special_requests,
      dietaryPreferences: t.dietary_preferences || [],
      estimatedTotal: Number(t.estimated_total),
      bundleDiscount: Number(t.bundle_discount || 0),
      finalPrice: Number(t.final_price),
      status: t.status,
      conciergeNotes: t.concierge_notes,
      quotedPrice: t.quoted_price ? Number(t.quoted_price) : undefined,
      convertedToPackageId: t.converted_to_package_id,
      createdAt: t.created_at,
      updatedAt: t.updated_at,
    }));
  },

  async createCustomTrip(trip: Partial<CustomTripRequest>): Promise<CustomTripRequest | null> {
    const row = {
      user_id: trip.userId,
      trip_title: trip.tripTitle,
      destination: trip.destination,
      country: trip.country,
      travel_style: trip.travelStyle,
      budget_tier: trip.budgetTier,
      start_date: trip.startDate,
      end_date: trip.endDate,
      duration_days: trip.durationDays,
      adults: trip.adults || 1,
      children: trip.children || 0,
      selected_listing_ids: trip.selectedListingIds || [],
      inclusions: trip.inclusions || [],
      special_requests: trip.specialRequests,
      dietary_preferences: trip.dietaryPreferences || [],
      estimated_total: trip.estimatedTotal || 0,
      bundle_discount: trip.bundleDiscount || 0,
      final_price: trip.finalPrice || 0,
      status: trip.status || 'SUBMITTED',
      itinerary: trip.itinerary || [],
    };

    const { data, error } = await supabase
      .from('custom_trips')
      .insert(row)
      .select()
      .single();

    if (error) {
      console.error('Supabase createCustomTrip error:', error);
      throw error;
    }

    return {
      ...(trip as CustomTripRequest),
      id: data.id,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    };
  },

  async updateCustomTrip(id: string, updates: Partial<CustomTripRequest>): Promise<CustomTripRequest | null> {
    const row: Record<string, any> = { updated_at: new Date().toISOString() };
    if (updates.status !== undefined) row.status = updates.status;
    if (updates.conciergeNotes !== undefined) row.concierge_notes = updates.conciergeNotes;
    if (updates.quotedPrice !== undefined) row.quoted_price = updates.quotedPrice;
    if (updates.convertedToPackageId !== undefined) row.converted_to_package_id = updates.convertedToPackageId;
    if (updates.tripTitle !== undefined) row.trip_title = updates.tripTitle;
    if (updates.itinerary !== undefined) row.itinerary = updates.itinerary;
    if (updates.finalPrice !== undefined) row.final_price = updates.finalPrice;

    const { data, error } = await supabase
      .from('custom_trips')
      .update(row)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Supabase updateCustomTrip error:', error);
      return null;
    }
    return data ? (data as unknown as CustomTripRequest) : null;
  },

  async deleteCustomTrip(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('custom_trips')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deleteCustomTrip error:', error);
      return false;
    }
    return true;
  },

  // ==================== AUDIT LOGS ====================
  async getAuditLogs(): Promise<AuditLog[]> {
    const { data, error } = await supabase
      .from('audit_logs')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(200);

    if (error) {
      console.warn('Supabase getAuditLogs error:', error);
      return [];
    }

    return (data || []).map((l: any) => ({
      id: l.id,
      action: l.action,
      performedBy: l.performed_by || l.performed_by_email || 'SYSTEM',
      performedByEmail: l.performed_by_email,
      targetId: l.target_id || '',
      targetType: l.target_type,
      ipAddress: l.ip_address || '127.0.0.1',
      timestamp: l.timestamp,
      details: l.details || {},
    }));
  },

  async addAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): Promise<AuditLog | null> {
    const { data, error } = await supabase
      .from('audit_logs')
      .insert({
        action: log.action,
        performed_by: log.performedBy,
        performed_by_email: log.performedByEmail || log.performedBy,
        target_id: log.targetId,
        target_type: log.targetType,
        ip_address: log.ipAddress || '127.0.0.1',
        details: log.details || {},
      })
      .select()
      .single();

    if (error) {
      console.warn('Supabase addAuditLog error:', error);
      return null;
    }

    return {
      id: data.id,
      action: data.action,
      performedBy: data.performed_by || data.performed_by_email || log.performedBy || 'SYSTEM',
      performedByEmail: data.performed_by_email || log.performedByEmail,
      targetId: data.target_id || log.targetId || '',
      targetType: data.target_type || log.targetType,
      ipAddress: data.ip_address || log.ipAddress || '127.0.0.1',
      timestamp: data.timestamp || new Date().toISOString(),
      details: data.details || log.details || {},
    };
  },

  async createAuditLog(log: Omit<AuditLog, 'id' | 'timestamp'>): Promise<AuditLog | null> {
    return SupabaseDataService.addAuditLog(log);
  },

  // ==================== USERS & PROFILES ====================
  async getProfiles(): Promise<User[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getProfiles error:', error);
      return [];
    }

    return (data || []).map((u: any) => ({
      uid: u.id,
      email: u.email,
      name: u.name,
      phoneNumber: u.phone_number,
      avatar: u.avatar_url,
      role: u.role,
      customTitle: u.custom_title,
      department: u.department,
      customPostId: u.custom_post_id,
      mfaEnabled: u.mfa_enabled,
      recoveryEmail: u.recovery_email,
      createdAt: u.created_at,
      status: u.status,
      lastLoginAt: u.last_login_at,
      lastLoginIp: u.last_login_ip,
      lastLoginDevice: u.last_login_device,
      lastLoginBrowser: u.last_login_browser,
      lastLoginOs: u.last_login_os,
      lastLoginTimezone: u.last_login_timezone,
      lastLoginScreen: u.last_login_screen,
    }));
  },

  async updateProfileRole(uid: string, role: string, customTitle?: string, department?: string, customPostId?: string): Promise<boolean> {
    const updates: Record<string, any> = { role, updated_at: new Date().toISOString() };
    if (customTitle !== undefined) updates.custom_title = customTitle;
    if (department !== undefined) updates.department = department;
    if (customPostId !== undefined) updates.custom_post_id = customPostId;

    const { error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', uid);

    if (error) {
      console.error('Supabase updateProfileRole error:', error);
      return false;
    }
    return true;
  },

  async updateUserStatus(uid: string, status: string): Promise<boolean> {
    const { error } = await supabase
      .from('profiles')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', uid);

    if (error) {
      console.error('Supabase updateUserStatus error:', error);
      return false;
    }
    return true;
  },

  async createProfile(user: Partial<User>): Promise<User | null> {
    const { data, error } = await supabase
      .from('profiles')
      .insert({
        id: user.uid,
        email: user.email,
        name: user.name,
        phone_number: user.phoneNumber,
        role: user.role,
        custom_title: user.customTitle,
        department: user.department,
        recovery_email: user.recoveryEmail,
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase createProfile error:', error);
      return null;
    }
    return {
      uid: data.id,
      email: data.email || user.email || '',
      name: data.name || user.name || 'User',
      phoneNumber: data.phone_number,
      avatar: data.avatar_url,
      role: (data.role || user.role || 'USER') as UserRole,
      customTitle: data.custom_title,
      department: data.department,
      mfaEnabled: Boolean(data.mfa_enabled),
      recoveryEmail: data.recovery_email,
      createdAt: data.created_at || new Date().toISOString(),
      status: data.status || 'ACTIVE',
    };
  },

  async deleteProfile(uid: string): Promise<boolean> {
    const { error } = await supabase
      .from('profiles')
      .delete()
      .eq('id', uid);

    if (error) {
      console.error('Supabase deleteProfile error:', error);
      return false;
    }
    return true;
  },

  // ==================== CUSTOM POSTS ====================
  async getCustomPosts(): Promise<CustomPost[]> {
    const { data, error } = await supabase
      .from('custom_posts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getCustomPosts error:', error);
      return [];
    }

    return (data || []).map((p: any) => ({
      id: p.id,
      title: p.title,
      department: p.department || '',
      baseRole: (p.base_role || 'ADMIN') as UserRole,
      description: p.description || 'Custom designated administrative post with configured privileges.',
      privileges: (p.privileges || []) as PostPrivilege[],
      badgeColor: (p.badge_color || 'amber') as any,
      color: p.color || '#3B82F6',
      badgeLabel: p.badge_label || p.title,
      createdBy: p.created_by,
      createdAt: p.created_at || new Date().toISOString(),
    }));
  },

  async saveCustomPost(post: CustomPost): Promise<boolean> {
    const anyPost = post as any;
    const { error } = await supabase
      .from('custom_posts')
      .upsert({
        id: post.id,
        title: post.title,
        department: post.department,
        base_role: post.baseRole,
        description: post.description,
        color: anyPost.color || post.badgeColor || '#3B82F6',
        badge_label: anyPost.badgeLabel || post.title,
        privileges: post.privileges,
        created_by: post.createdBy,
      });

    if (error) {
      console.error('Supabase saveCustomPost error:', error);
      return false;
    }
    return true;
  },

  async deleteCustomPost(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('custom_posts')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deleteCustomPost error:', error);
      return false;
    }
    return true;
  },

  // ==================== ACTIVE SESSIONS ====================
  async getActiveSessions(): Promise<any[]> {
    const { data, error } = await supabase
      .from('active_sessions')
      .select('*')
      .order('last_heartbeat', { ascending: false });

    if (error) {
      console.warn('Supabase getActiveSessions error:', error);
      return [];
    }

    return (data || []).map((s: any) => ({
      uid: s.uid,
      name: s.name,
      email: s.email,
      role: s.role,
      customTitle: s.custom_title,
      ipAddress: s.ip_address,
      device: s.device,
      browser: s.browser,
      os: s.os,
      status: s.status,
      lastHeartbeat: s.last_heartbeat,
      loginTime: s.login_time,
    }));
  },

  async recordSessionHeartbeat(session: {
    uid: string;
    name: string;
    email: string;
    role: string;
    customTitle?: string;
    ipAddress?: string;
    device?: string;
    browser?: string;
    os?: string;
    status?: string;
    loginTime?: string;
  }): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('active_sessions')
        .upsert({
          uid: session.uid,
          name: session.name,
          email: session.email,
          role: session.role,
          custom_title: session.customTitle,
          ip_address: session.ipAddress || '127.0.0.1',
          device: session.device,
          browser: session.browser,
          os: session.os,
          status: session.status || 'ONLINE',
          last_heartbeat: new Date().toISOString(),
          login_time: session.loginTime || new Date().toISOString(),
        }, { onConflict: 'uid' });
      return !error;
    } catch {
      return false;
    }
  },

  async revokeSession(uid: string): Promise<boolean> {
    const { error } = await supabase
      .from('active_sessions')
      .delete()
      .eq('uid', uid);

    if (error) {
      console.error('Supabase revokeSession error:', error);
      return false;
    }
    return true;
  },

  // ==================== REPORTED REVIEWS MODERATION ====================
  async getReportedReviews(): Promise<Review[]> {
    const { data, error } = await supabase
      .from('reviews')
      .select(`
        id,
        listing_id,
        user_id,
        rating,
        comment,
        is_reported,
        report_reason,
        moderation_status,
        created_at,
        profiles (
          name,
          email,
          avatar_url
        ),
        listings (
          title
        )
      `)
      .eq('is_reported', true)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getReportedReviews error:', error);
      return [];
    }

    return (data || []).map((r: any) => ({
      id: r.id,
      listingId: r.listing_id,
      listingTitle: r.listings?.title || 'Experience',
      userId: r.user_id,
      userName: r.profiles?.name || 'Traveler',
      userEmail: r.profiles?.email || '',
      userAvatar: r.profiles?.avatar_url,
      rating: r.rating,
      comment: r.comment,
      isReported: r.is_reported,
      reportReason: r.report_reason,
      moderationStatus: r.moderation_status,
      createdAt: r.created_at,
    }));
  },

  async moderateReview(id: string, action: 'DISMISS' | 'REMOVE'): Promise<boolean> {
    if (action === 'REMOVE') {
      const { error } = await supabase.from('reviews').delete().eq('id', id);
      return !error;
    } else {
      const { error } = await supabase
        .from('reviews')
        .update({ is_reported: false, moderation_status: 'DISMISSED' })
        .eq('id', id);
      return !error;
    }
  },

  // ==================== STORAGE UPLOADS ====================
  async uploadImage(bucket: 'listings' | 'avatars', file: File, path: string): Promise<string | null> {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, { upsert: true });

    if (error) {
      console.error(`Supabase uploadImage (${bucket}) error:`, error);
      throw error;
    }

    const { data: publicUrlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    return publicUrlData.publicUrl;
  },

  // ==================== PRICE ALERTS ====================
  async getPriceAlertForUserAndListing(userId: string, listingId: string): Promise<PriceAlert | null> {
    const { data, error } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('user_id', userId)
      .eq('listing_id', listingId)
      .maybeSingle();

    if (error || !data) return null;

    return {
      id: data.id,
      userId: data.user_id,
      userEmail: data.user_email || '',
      listingId: data.listing_id,
      listingTitle: data.listing_title || '',
      targetPrice: Number(data.target_price),
      active: data.active,
      createdAt: data.created_at || new Date().toISOString(),
    };
  },

  async savePriceAlert(alert: PriceAlert): Promise<boolean> {
    const { error } = await supabase
      .from('price_alerts')
      .upsert({
        id: alert.id,
        user_id: alert.userId,
        user_email: alert.userEmail,
        listing_id: alert.listingId,
        listing_title: alert.listingTitle,
        target_price: alert.targetPrice,
        active: alert.active,
      });

    if (error) {
      console.error('Supabase savePriceAlert error:', error);
      return false;
    }
    return true;
  },

  async deletePriceAlert(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('price_alerts')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deletePriceAlert error:', error);
      return false;
    }
    return true;
  },

  // ==================== FEED POSTS ====================
  async getFeedPosts(): Promise<FeedPost[]> {
    const { data, error } = await supabase
      .from('feed_posts')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase getFeedPosts error:', error);
      return [];
    }

    return (data || []).map((f: any) => ({
      id: f.id,
      authorId: f.author_id,
      authorName: f.author_name || 'Voyage Explorer',
      authorRole: f.author_role || 'EXPLORER',
      content: f.content,
      pinned: f.pinned || false,
      likes: f.likes || 0,
      createdAt: f.created_at,
    }));
  },

  async createFeedPost(post: { authorId: string; authorName: string; authorRole?: string; content: string }): Promise<FeedPost | null> {
    const { data, error } = await supabase
      .from('feed_posts')
      .insert({
        author_id: post.authorId,
        author_name: post.authorName,
        author_role: post.authorRole || 'EXPLORER',
        content: post.content,
      })
      .select()
      .single();

    if (error) {
      console.error('Supabase createFeedPost error:', error);
      return null;
    }

    return {
      id: data.id,
      authorId: data.author_id || post.authorId,
      authorName: data.author_name || post.authorName,
      authorRole: data.author_role || post.authorRole || 'EXPLORER',
      content: data.content || post.content,
      pinned: data.pinned || false,
      likes: data.likes || 0,
      createdAt: data.created_at || new Date().toISOString(),
    };
  },

  async deleteFeedPost(id: string): Promise<boolean> {
    const { error } = await supabase
      .from('feed_posts')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Supabase deleteFeedPost error:', error);
      return false;
    }
    return true;
  },

  // ==================== REALTIME CHANNELS ====================
  subscribeToListingChanges(callback: (payload: any) => void) {
    return supabase
      .channel('public:listings')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'listings' }, callback)
      .subscribe();
  },

  subscribeToAuditLogChanges(callback: (payload: any) => void) {
    return supabase
      .channel('public:audit_logs')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'audit_logs' }, callback)
      .subscribe();
  }
};
