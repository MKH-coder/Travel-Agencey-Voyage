/**
 * ClientStorageManager - Dedicated exclusively to transient UI state & preferences.
 * Database entities (users, listings, bookings, custom posts, audit logs) reside strictly in Supabase.
 */

export interface UiPreferences {
  themeMode: string;
  sidebarOpen: boolean;
  onboardingCompleted: boolean;
  dismissedBanners: string[];
}

const UI_PREFS_KEY = 'voyage_ui_preferences';

export class ClientStorageManager {
  private static getPreferences(): UiPreferences {
    try {
      const raw = localStorage.getItem(UI_PREFS_KEY);
      if (raw) return JSON.parse(raw);
    } catch {
      // fallback
    }
    return {
      themeMode: 'cyan-light',
      sidebarOpen: true,
      onboardingCompleted: false,
      dismissedBanners: [],
    };
  }

  private static savePreferences(prefs: UiPreferences): void {
    try {
      localStorage.setItem(UI_PREFS_KEY, JSON.stringify(prefs));
    } catch {
      // ignore
    }
  }

  public static getTheme(): string {
    return this.getPreferences().themeMode;
  }

  public static setTheme(theme: string): void {
    const prefs = this.getPreferences();
    prefs.themeMode = theme;
    this.savePreferences(prefs);
  }

  public static isBannerDismissed(bannerId: string): boolean {
    return this.getPreferences().dismissedBanners.includes(bannerId);
  }

  public static dismissBanner(bannerId: string): void {
    const prefs = this.getPreferences();
    if (!prefs.dismissedBanners.includes(bannerId)) {
      prefs.dismissedBanners.push(bannerId);
      this.savePreferences(prefs);
    }
  }

  public static getSidebarState(): boolean {
    return this.getPreferences().sidebarOpen;
  }

  public static setSidebarState(open: boolean): void {
    const prefs = this.getPreferences();
    prefs.sidebarOpen = open;
    this.savePreferences(prefs);
  }
}
