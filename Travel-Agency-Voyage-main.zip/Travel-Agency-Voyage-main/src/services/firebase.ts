// Deprecated - Replaced completely with Supabase
export {};
