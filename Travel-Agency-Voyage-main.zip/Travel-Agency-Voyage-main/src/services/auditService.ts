import { AuditLog, User } from '../types.ts';
import { SupabaseDataService } from './supabaseService.ts';

export interface AuditLogOptions {
  action: string;
  targetId: string;
  targetType?: string;
  performedBy?: string;
  performedByEmail?: string;
  ipAddress?: string;
  details?: Record<string, unknown>;
}

export class AuditService {
  /**
   * Records an administrative action directly in Supabase audit_logs table.
   */
  static async recordAction(
    options: AuditLogOptions,
    adminUser?: User | null,
    _authToken?: string | null
  ): Promise<AuditLog> {
    const adminId = options.performedBy || adminUser?.uid || adminUser?.email || 'SYSTEM_ADMIN';
    const adminEmail = options.performedByEmail || adminUser?.email || undefined;
    const timestamp = new Date().toISOString();

    const logEntry: Omit<AuditLog, 'id' | 'timestamp'> = {
      action: options.action,
      performedBy: adminId,
      performedByEmail: adminEmail,
      targetId: options.targetId,
      targetType: options.targetType || 'ADMIN_ACTION',
      ipAddress: options.ipAddress || '127.0.0.1',
      details: {
        timestamp,
        adminId,
        adminEmail,
        ...options.details,
      },
    };

    const savedLog = await SupabaseDataService.addAuditLog(logEntry);
    if (savedLog) {
      return savedLog;
    }

    return {
      ...logEntry,
      id: `audit_${Date.now()}`,
      timestamp,
    };
  }
}
