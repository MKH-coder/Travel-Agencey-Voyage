import { CustomTripRequest } from '../types.ts';
import { SupabaseDataService } from './supabaseService.ts';

export const customTripService = {
  async getTrips(userEmail?: string): Promise<CustomTripRequest[]> {
    return SupabaseDataService.getCustomTrips(userEmail);
  },

  async createTrip(tripData: Partial<CustomTripRequest>): Promise<CustomTripRequest> {
    const created = await SupabaseDataService.createCustomTrip(tripData);
    if (!created) {
      throw new Error('Failed to create custom trip in Supabase.');
    }
    return created;
  },

  async updateTrip(
    id: string,
    updates: Partial<CustomTripRequest> & { convertToPackage?: boolean; packageTitle?: string; packagePrice?: number; packageDescription?: string }
  ): Promise<CustomTripRequest | null> {
    return SupabaseDataService.updateCustomTrip(id, updates);
  },

  async deleteTrip(id: string): Promise<boolean> {
    return SupabaseDataService.deleteCustomTrip(id);
  }
};
