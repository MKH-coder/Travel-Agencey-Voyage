import { SUPABASE_URL, SUPABASE_ANON_KEY } from '../supabaseClient.js';

export { SUPABASE_URL, SUPABASE_ANON_KEY };

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_REF || (SUPABASE_URL ? new URL(SUPABASE_URL).hostname.split('.')[0] : '');
export const SUPABASE_CONSOLE_URL = projectRef 
  ? `https://supabase.com/dashboard/project/${projectRef}`
  : 'https://supabase.com/dashboard';

export type SupabaseSyncStatus = 'syncing' | 'synced' | 'offline';

export interface SupabaseSyncState {
  status: SupabaseSyncStatus;
  lastSyncedAt: Date | null;
  latencyMs: number | null;
  message: string;
  activeOperations: number;
}

type SyncStateListener = (state: SupabaseSyncState) => void;

class SupabaseSyncManager {
  private state: SupabaseSyncState = {
    status: 'synced',
    lastSyncedAt: new Date(),
    latencyMs: null,
    message: 'Pure Supabase Active',
    activeOperations: 0,
  };

  private listeners: Set<SyncStateListener> = new Set();

  getSyncState(): SupabaseSyncState {
    return { ...this.state };
  }

  subscribe(listener: SyncStateListener): () => void {
    this.listeners.add(listener);
    listener(this.getSyncState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const currentState = this.getSyncState();
    this.listeners.forEach(fn => fn(currentState));
  }

  async testConnection(): Promise<{ online: boolean; latencyMs?: number; message?: string }> {
    const start = performance.now();
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/`, {
        method: 'GET',
        headers: {
          apikey: SUPABASE_ANON_KEY,
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
      });

      const latencyMs = Math.round(performance.now() - start);

      if (res.ok || res.status === 200 || res.status === 404 || res.status === 401) {
        this.state = {
          status: 'synced',
          lastSyncedAt: new Date(),
          latencyMs,
          message: `Connected (${latencyMs}ms)`,
          activeOperations: 0,
        };
        this.notify();
        return { online: true, latencyMs, message: `Connected (${latencyMs}ms)` };
      }

      throw new Error(`HTTP ${res.status}`);
    } catch (err: any) {
      this.state = {
        status: 'offline',
        lastSyncedAt: null,
        latencyMs: null,
        message: err?.message || 'Connection failed',
        activeOperations: 0,
      };
      this.notify();
      return { online: false, message: err?.message || 'Connection failed' };
    }
  }
}

export const SupabaseSyncService = new SupabaseSyncManager();
