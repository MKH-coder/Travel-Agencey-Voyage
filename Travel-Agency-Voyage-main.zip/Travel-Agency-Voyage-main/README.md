# Voyage - Luxury Travel Agency & Booking Platform

A full-stack travel agency web application built with **React 19**, **Vite**, **TypeScript**, **Tailwind CSS**, and **Supabase**.

---

## 📋 System Requirements & Prerequisites

Before running the project, ensure you have the following installed:

| Prerequisite | Recommended Version | Download Link |
|---|---|---|
| **Node.js** | `v18.x` or `v20.x`+ (LTS) | [nodejs.org](https://nodejs.org/) |
| **npm** | `v9.x` or `v10.x`+ | Included with Node.js |
| **Git** | Latest | [git-scm.com](https://git-scm.com/) |
| **Supabase Account** | Free tier is sufficient | [supabase.com](https://supabase.com/) |

> **Note:** In Node.js / JavaScript projects, dependencies are managed via `package.json` using `npm install` (equivalent to `pip install -r requirements.txt` in Python).

---

## 🚀 Quick Start Guide

### 1. Install Dependencies
Open your terminal in the project root directory and run:
```bash
npm install
```

---

### 2. Environment Variables Setup
Copy the example environment configuration file to create your local `.env`:

**Windows (PowerShell):**
```powershell
Copy-Item .env.example .env
```

**macOS / Linux:**
```bash
cp .env.example .env
```

Open `.env` and fill in your Supabase credentials:
```env
# Supabase Configuration
VITE_SUPABASE_URL=https://<your-project-ref>.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_key_here
VITE_SUPABASE_PROJECT_REF=<your-project-ref>

# Optional / Backend (if using server utilities)
SUPABASE_URL=https://<your-project-ref>.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_your_key_here
SUPABASE_PROJECT_REF=<your-project-ref>
SUPABASE_SECRET_KEY=your_service_role_key_if_needed
```

---

### 3. Database Setup (Supabase)

1. Log into your [Supabase Dashboard](https://supabase.com/dashboard).
2. Create a new project (or select an existing one).
3. In the left navigation, click **SQL Editor**.
4. Open the SQL file located at:
   ```
   supabase/migrations/20260929000000_initial_schema.sql
   ```
5. Paste the entire SQL content into the Supabase SQL Editor and click **Run**.
6. This automatically creates:
   - `profiles` table
   - `listings` table
   - `bookings` table
   - `custom_bookings` table
   - `reviews` table
   - `site_content` table
   - Row-Level Security (RLS) policies and triggers

---

### 4. Start the Development Server
Run the local dev server:
```bash
npm run dev
```

Once started, open your browser and navigate to:
```
http://localhost:3000
```

---

## 🛠️ Available Scripts

In the project directory, you can run:

| Command | Description |
|---|---|
| `npm run dev` | Runs the app in development mode on port 3000 |
| `npm run build` | Compiles TypeScript and creates optimized production build in `dist/` |
| `npm run preview` | Locally preview the production build |
| `npm run lint` | Runs TypeScript type checking (`tsc --noEmit`) |
| `npm run deploy` | Deploys the built distribution to GitHub Pages |

---

## 📦 Project Structure

```
├── public/                 # Static assets (favicons, images)
├── server/                 # Backend helpers & Supabase server clients
├── src/
│   ├── components/         # Reusable UI components & features
│   ├── context/            # React context providers (AuthContext, etc.)
│   ├── lib/                # Client utilities & Supabase client
│   ├── types/              # TypeScript interface definitions
│   ├── App.tsx             # Main App root component
│   ├── index.css           # Global Tailwind CSS styles
│   └── main.tsx            # React application entry point
├── supabase/
│   └── migrations/         # Database migration SQL scripts
├── .env.example            # Sample environment variables template
├── package.json            # Project dependencies and npm scripts
├── tsconfig.json           # TypeScript configuration
└── vite.config.ts          # Vite configuration
```

---

## ⚠️ Notes for Sharing / Handover

When sharing this project (via ZIP, GitHub, or Drive):
1. **DO NOT include `node_modules/`** — It is very large (hundreds of MBs). The recipient can generate it by running `npm install`.
2. **DO NOT share your private `.env` file** if it contains sensitive secret keys. Always share `.env.example` so they can plug in their own keys.
3. The `.gitignore` is already set up to ignore build artifacts and secret files.
