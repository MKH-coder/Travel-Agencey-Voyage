// Deprecated - Replaced by src/supabaseClient.js and src/services/supabaseService.ts
export {};
