// Deprecated - Replaced by src/types.ts
export {};
