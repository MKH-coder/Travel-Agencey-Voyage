// Deprecated - Replaced by Supabase Auth and Row Level Security
export {};
