// Deprecated - Replaced by direct Supabase PostgreSQL
export {};
