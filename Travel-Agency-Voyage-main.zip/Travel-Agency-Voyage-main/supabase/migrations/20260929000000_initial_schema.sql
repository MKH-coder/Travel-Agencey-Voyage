-- Voyage Pure Supabase Schema for vamcthddxqedfeajdrqc

-- 1. Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT,
  phone_number TEXT,
  role TEXT DEFAULT 'USER',
  custom_title TEXT,
  department TEXT,
  custom_post_id TEXT,
  avatar_url TEXT,
  mfa_enabled BOOLEAN DEFAULT FALSE,
  recovery_email TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Listings Table
CREATE TABLE IF NOT EXISTS public.listings (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  price NUMERIC NOT NULL,
  rating NUMERIC DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  location TEXT,
  country TEXT,
  lat NUMERIC,
  lng NUMERIC,
  description TEXT,
  images TEXT[] DEFAULT '{}',
  status TEXT DEFAULT 'PUBLISHED',
  created_by TEXT,
  created_by_name TEXT,
  approved_by TEXT,
  rejection_reason TEXT,
  tags TEXT[] DEFAULT '{}',
  amenities TEXT[] DEFAULT '{}',
  dining_specialties TEXT[] DEFAULT '{}',
  hotel_perks TEXT[] DEFAULT '{}',
  listing_ids TEXT[] DEFAULT '{}',
  duration TEXT,
  pinned BOOLEAN DEFAULT FALSE,
  pinned_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Bookings Table
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT REFERENCES public.listings(id) ON DELETE CASCADE,
  user_id TEXT,
  check_in_date DATE NOT NULL,
  check_out_date DATE,
  guests INTEGER DEFAULT 1,
  total_price NUMERIC NOT NULL,
  status TEXT DEFAULT 'CONFIRMED',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Custom Posts Table
CREATE TABLE IF NOT EXISTS public.custom_posts (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  department TEXT,
  color TEXT DEFAULT '#3B82F6',
  badge_label TEXT,
  privileges TEXT[] DEFAULT '{}',
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Audit Logs Table
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action TEXT NOT NULL,
  performed_by_email TEXT,
  target_id TEXT,
  target_type TEXT,
  ip_address TEXT DEFAULT '127.0.0.1',
  details JSONB DEFAULT '{}'::jsonb,
  timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Custom Trips Table
CREATE TABLE IF NOT EXISTS public.custom_trips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  trip_title TEXT NOT NULL,
  destination TEXT,
  country TEXT,
  travel_style TEXT,
  budget_tier TEXT,
  start_date DATE,
  end_date DATE,
  duration_days INTEGER,
  adults INTEGER DEFAULT 1,
  children INTEGER DEFAULT 0,
  selected_listing_ids TEXT[] DEFAULT '{}',
  inclusions TEXT[] DEFAULT '{}',
  special_requests TEXT,
  dietary_preferences TEXT[] DEFAULT '{}',
  estimated_total NUMERIC,
  bundle_discount NUMERIC DEFAULT 0,
  final_price NUMERIC,
  status TEXT DEFAULT 'SUBMITTED',
  itinerary JSONB DEFAULT '[]'::jsonb,
  concierge_notes TEXT,
  quoted_price NUMERIC,
  converted_to_package_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. Reviews Table
CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id TEXT REFERENCES public.listings(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  is_reported BOOLEAN DEFAULT FALSE,
  report_reason TEXT,
  reported_by TEXT,
  moderation_status TEXT DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Feed Posts Table
CREATE TABLE IF NOT EXISTS public.feed_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id TEXT NOT NULL,
  author_name TEXT NOT NULL,
  author_role TEXT DEFAULT 'EXPLORER',
  content TEXT NOT NULL,
  pinned BOOLEAN DEFAULT FALSE,
  likes INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. Active Sessions Table
CREATE TABLE IF NOT EXISTS public.active_sessions (
  uid TEXT PRIMARY KEY,
  name TEXT,
  email TEXT,
  role TEXT,
  custom_title TEXT,
  ip_address TEXT,
  device TEXT,
  browser TEXT,
  os TEXT,
  status TEXT DEFAULT 'ONLINE',
  last_heartbeat TIMESTAMPTZ DEFAULT NOW(),
  login_time TIMESTAMPTZ DEFAULT NOW()
);

-- 10. Enable Row Level Security (RLS) & Allow Read/Write
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on profiles" ON public.profiles;
CREATE POLICY "Allow all on profiles" ON public.profiles FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on listings" ON public.listings;
CREATE POLICY "Allow all on listings" ON public.listings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on bookings" ON public.bookings;
CREATE POLICY "Allow all on bookings" ON public.bookings FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.custom_posts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on custom_posts" ON public.custom_posts;
CREATE POLICY "Allow all on custom_posts" ON public.custom_posts FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on audit_logs" ON public.audit_logs;
CREATE POLICY "Allow all on audit_logs" ON public.audit_logs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.custom_trips ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on custom_trips" ON public.custom_trips;
CREATE POLICY "Allow all on custom_trips" ON public.custom_trips FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on reviews" ON public.reviews;
CREATE POLICY "Allow all on reviews" ON public.reviews FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.feed_posts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on feed_posts" ON public.feed_posts;
CREATE POLICY "Allow all on feed_posts" ON public.feed_posts FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.active_sessions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all on active_sessions" ON public.active_sessions;
CREATE POLICY "Allow all on active_sessions" ON public.active_sessions FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 11. Storage Buckets (for image uploads)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('listings', 'listings', true), ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Allow all on listings bucket" ON storage.objects;
CREATE POLICY "Allow all on listings bucket" ON storage.objects FOR ALL TO anon, authenticated USING (bucket_id IN ('listings', 'avatars')) WITH CHECK (bucket_id IN ('listings', 'avatars'));

-- 12. Seed Initial Travel Listings
INSERT INTO public.listings (id, title, category, price, rating, review_count, location, country, description, images, status, tags, amenities)
VALUES 
('list-santorini-01', 'Santorini Caldera Cliffside & Oia Sunset Panorama', 'HOTEL', 420, 4.9, 128, 'Oia', 'Greece', 'A private cliffside suite overlooking the caldera, with an infinity plunge pool and front-row seats to the Oia sunset.', ARRAY['https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1200&q=80'], 'PUBLISHED', ARRAY['Sunset View', 'Cliffside', 'Romantic'], ARRAY['WiFi', 'Private Pool', 'Breakfast Included']),
('list-kyoto-02', 'Arashiyama Bamboo Grove & Tenryu-ji Temple Tour', 'PLACE', 95, 4.8, 76, 'Kyoto', 'Japan', 'An early-morning guided walk through the bamboo grove and the Zen garden of Tenryu-ji, before the crowds arrive.', ARRAY['https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80'], 'PUBLISHED', ARRAY['Culture', 'Guided Tour', 'Early Morning'], ARRAY['Guide Included', 'Tea Ceremony']),
('list-amalfi-03', 'Amalfi Coast Lemon Grove Terrace & Sea-Cliff Elevator', 'HOTEL', 380, 4.9, 54, 'Positano', 'Italy', 'A terrace suite among the lemon groves with a private elevator down to the Tyrrhenian Sea.', ARRAY['https://images.unsplash.com/photo-1533104816931-20fa691ff6ca?auto=format&fit=crop&w=1200&q=80'], 'PUBLISHED', ARRAY['Sea View', 'Terrace', 'Coastal'], ARRAY['Private Elevator', 'Breakfast Included', 'WiFi'])
ON CONFLICT (id) DO NOTHING;
