-- ============================================================================
-- Voyage Travel Platform — Supabase schema
-- ============================================================================
-- Run this once in your Supabase project's SQL editor
-- (https://supabase.com/dashboard/project/_/sql/new).
--
-- WHY THIS FILE EXISTS
-- The site is deployed as a static build to GitHub Pages, which cannot run
-- the Express server (server.ts). That means the browser talks to Supabase
-- directly using the public "anon" key. These tables are what make an
-- admin's post, a new listing, or a signed-in account visible on every
-- device instead of being stuck in that one browser's localStorage.
--
-- SECURITY NOTE (please read)
-- The anon key is meant to be public, but the policies below are
-- intentionally permissive (anyone can read/write) so the app keeps working
-- exactly as it does today. That is fine for a personal/demo project, but
-- before this is a real production site with real users, tighten the
-- WITH CHECK / USING clauses below — e.g. only allow INSERT/UPDATE/DELETE
-- on "listings" and "feed_posts" for authenticated Supabase users whose
-- role is ADMIN/TECH_ADMIN, rather than "true" for everyone.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- listings — the PLACE / HOTEL / FOOD cards shown on the explore screen
-- ----------------------------------------------------------------------------
create table if not exists public.listings (
  id text primary key,
  title text not null,
  description text,
  category text not null default 'PLACE',
  location text,
  country text,
  price numeric default 199,
  rating numeric default 4.9,
  images jsonb default '[]'::jsonb,
  tags jsonb default '[]'::jsonb,
  amenities jsonb default '[]'::jsonb,
  status text not null default 'PUBLISHED',
  "createdBy" text,
  "createdByName" text,
  "createdAt" timestamptz default now()
);

-- ----------------------------------------------------------------------------
-- feed_posts — admin "broadcast" announcements shown to every visitor
-- ----------------------------------------------------------------------------
create table if not exists public.feed_posts (
  id text primary key,
  "authorId" text,
  "authorName" text,
  content text not null,
  "createdAt" timestamptz default now()
);

-- ----------------------------------------------------------------------------
-- users — mirrors signed-in accounts so a returning user keeps their role
-- ----------------------------------------------------------------------------
create table if not exists public.users (
  uid text primary key,
  email text unique,
  name text,
  role text not null default 'USER',
  "customTitle" text,
  department text,
  avatar text,
  "mfaEnabled" boolean default false,
  status text default 'ACTIVE',
  "lastLoginAt" timestamptz,
  "createdAt" timestamptz default now()
);

-- ----------------------------------------------------------------------------
-- custom_posts — admin role/title definitions (privileges), not feed content
-- ----------------------------------------------------------------------------
create table if not exists public.custom_posts (
  id text primary key,
  title text not null,
  description text,
  department text,
  privileges jsonb default '[]'::jsonb,
  "baseRole" text default 'ADMIN',
  "createdAt" timestamptz default now()
);

-- ----------------------------------------------------------------------------
-- audit_logs — admin action history
-- ----------------------------------------------------------------------------
create table if not exists public.audit_logs (
  id text primary key,
  action text not null,
  "performedBy" text,
  "targetId" text,
  timestamp timestamptz default now(),
  details jsonb
);

-- ----------------------------------------------------------------------------
-- bookings
-- ----------------------------------------------------------------------------
create table if not exists public.bookings (
  id text primary key,
  "userId" text,
  "listingId" text,
  "listingTitle" text,
  "listingImage" text,
  "listingCategory" text,
  "checkInDate" text,
  "checkOutDate" text,
  guests integer default 1,
  "totalPrice" numeric default 0,
  status text default 'CONFIRMED',
  "createdAt" timestamptz default now()
);

-- ----------------------------------------------------------------------------
-- price_alerts
-- ----------------------------------------------------------------------------
create table if not exists public.price_alerts (
  id text primary key,
  "userId" text,
  "userEmail" text,
  "listingId" text,
  "listingTitle" text,
  "targetPrice" numeric,
  active boolean default true,
  "createdAt" timestamptz default now()
);

-- ============================================================================
-- Row Level Security — enabled + permissive, matching the app's current
-- "anon key does everything" design. See the security note above.
-- ============================================================================
alter table public.listings enable row level security;
alter table public.feed_posts enable row level security;
alter table public.users enable row level security;
alter table public.custom_posts enable row level security;
alter table public.audit_logs enable row level security;
alter table public.bookings enable row level security;
alter table public.price_alerts enable row level security;

do $$
declare
  t text;
begin
  foreach t in array array['listings','feed_posts','users','custom_posts','audit_logs','bookings','price_alerts']
  loop
    execute format('drop policy if exists "public_all_%1$s" on public.%1$s;', t);
    execute format(
      'create policy "public_all_%1$s" on public.%1$s for all using (true) with check (true);',
      t
    );
  end loop;
end $$;
