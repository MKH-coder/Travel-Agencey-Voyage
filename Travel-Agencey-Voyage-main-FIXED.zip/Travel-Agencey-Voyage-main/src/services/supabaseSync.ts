import { Listing, User, CustomPost, AuditLog, Booking, PriceAlert, FeedPost } from '../types.ts';

export const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'https://iunwfdzefyvwcvalhdzv.supabase.co';
export const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_eb6-PYu0SLS5QlB4cBFMXg_a3UrtWNG';
export const SUPABASE_CONSOLE_URL = 'https://supabase.com/dashboard';

export type SupabaseSyncStatus = 'syncing' | 'synced' | 'offline';

export interface SupabaseSyncState {
  status: SupabaseSyncStatus;
  lastSyncedAt: Date | null;
  latencyMs: number | null;
  message: string;
  activeOperations: number;
}

type SyncStateListener = (state: SupabaseSyncState) => void;

export class SupabaseSyncService {
  private static currentState: SupabaseSyncState = {
    status: 'synced',
    lastSyncedAt: new Date(),
    latencyMs: 45,
    message: 'Supabase PostgreSQL connected',
    activeOperations: 0
  };

  private static listeners: Set<SyncStateListener> = new Set();

  public static getSyncState(): SupabaseSyncState {
    return { ...this.currentState };
  }

  public static subscribe(listener: SyncStateListener): () => void {
    this.listeners.add(listener);
    listener({ ...this.currentState });
    return () => {
      this.listeners.delete(listener);
    };
  }

  private static notifyListeners() {
    const stateCopy = { ...this.currentState };
    this.listeners.forEach(fn => {
      try {
        fn(stateCopy);
      } catch (err) {
        console.error('Error in sync listener:', err);
      }
    });
  }

  public static setSyncing(actionDesc: string = 'Syncing with Supabase...') {
    this.currentState.activeOperations += 1;
    this.currentState.status = 'syncing';
    this.currentState.message = actionDesc;
    this.notifyListeners();
  }

  public static setSynced(latencyMs: number = 50, message: string = 'Synced with Supabase') {
    this.currentState.activeOperations = Math.max(0, this.currentState.activeOperations - 1);
    if (this.currentState.activeOperations === 0) {
      this.currentState.status = 'synced';
      this.currentState.lastSyncedAt = new Date();
      this.currentState.latencyMs = latencyMs;
      this.currentState.message = message;
    }
    this.notifyListeners();
  }

  public static setOffline(errorMsg: string = 'Supabase connection offline') {
    this.currentState.activeOperations = Math.max(0, this.currentState.activeOperations - 1);
    this.currentState.status = 'offline';
    this.currentState.latencyMs = null;
    this.currentState.message = errorMsg;
    this.notifyListeners();
  }

  static async testConnection(): Promise<{ success: boolean; latencyMs: number; message: string }> {
    const start = Date.now();
    this.setSyncing('Pinging Supabase REST API...');
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/listings?select=id&limit=1`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const latencyMs = Date.now() - start;
      if (res.ok) {
        this.setSynced(latencyMs, `Connected to Supabase PostgreSQL (${latencyMs}ms)`);
        return {
          success: true,
          latencyMs,
          message: `Connected to Supabase PostgreSQL Database in ${latencyMs}ms.`
        };
      } else {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      this.setOffline(`Connection check failed: ${errorMsg}`);
      return {
        success: false,
        latencyMs: Date.now() - start,
        message: `Supabase connection failed: ${errorMsg}`
      };
    }
  }

  static async bulkSyncAllToSupabase(payload: {
    listings: Listing[];
    users: User[];
    customPosts: CustomPost[];
    auditLogs: AuditLog[];
    bookings?: Booking[];
    priceAlerts?: PriceAlert[];
  }): Promise<{
    success: boolean;
    syncedCounts: { listings: number; users: number; customPosts: number; auditLogs: number; bookings: number; priceAlerts: number };
    error?: string;
  }> {
    const startTime = Date.now();
    this.setSyncing('Performing bulk database sync to Supabase...');
    const counts = { listings: 0, users: 0, customPosts: 0, auditLogs: 0, bookings: 0, priceAlerts: 0 };
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates' // Simulate relational UPSERT
      };

      // 1. Listings Table Upsert
      if (payload.listings.length > 0) {
        const mappedListings = payload.listings.map(item => ({
          id: item.id,
          title: item.title,
          description: item.description,
          category: item.category,
          location: item.location,
          country: item.country,
          price: Number(item.price),
          rating: Number(item.rating),
          images: item.images,
          status: item.status,
          createdAt: new Date().toISOString()
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/listings`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedListings)
        });
        if (res.ok) counts.listings = mappedListings.length;
      }

      // 2. Users Table Upsert
      if (payload.users.length > 0) {
        const mappedUsers = payload.users.map(item => ({
          uid: item.uid,
          name: item.name,
          email: item.email,
          role: item.role,
          customTitle: item.customTitle || null,
          department: item.department || null,
          avatar: item.avatar || null,
          createdAt: item.createdAt || new Date().toISOString()
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/users`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedUsers)
        });
        if (res.ok) counts.users = mappedUsers.length;
      }

      // 3. Custom Posts Table Upsert
      if (payload.customPosts.length > 0) {
        const mappedPosts = payload.customPosts.map(item => ({
          id: item.id,
          title: item.title,
          description: item.description,
          department: item.department,
          privileges: item.privileges,
          baseRole: item.baseRole || 'ADMIN',
          createdAt: item.createdAt || new Date().toISOString()
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_posts`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedPosts)
        });
        if (res.ok) counts.customPosts = mappedPosts.length;
      }

      // 4. Audit Logs Table Upsert
      if (payload.auditLogs.length > 0) {
        const mappedLogs = payload.auditLogs.slice(0, 50).map(item => ({
          id: item.id,
          action: item.action,
          performedBy: item.performedBy,
          targetId: item.targetId || null,
          timestamp: item.timestamp,
          details: item.details || null
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/audit_logs`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedLogs)
        });
        if (res.ok) counts.auditLogs = mappedLogs.length;
      }

      // 5. Bookings Table Upsert
      if (payload.bookings && payload.bookings.length > 0) {
        const mappedBookings = payload.bookings.map(item => ({
          id: item.id,
          userId: item.userId,
          listingId: item.listingId,
          listingTitle: item.listingTitle,
          listingImage: item.listingImage,
          listingCategory: item.listingCategory,
          checkInDate: item.checkInDate,
          checkOutDate: item.checkOutDate || null,
          guests: Number(item.guests),
          totalPrice: Number(item.totalPrice),
          status: item.status,
          createdAt: item.createdAt || new Date().toISOString()
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/bookings`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedBookings)
        });
        if (res.ok) counts.bookings = mappedBookings.length;
      }

      // 6. Price Alerts Table Upsert
      if (payload.priceAlerts && payload.priceAlerts.length > 0) {
        const mappedAlerts = payload.priceAlerts.map(item => ({
          id: item.id,
          userId: item.userId,
          userEmail: item.userEmail,
          listingId: item.listingId,
          listingTitle: item.listingTitle,
          targetPrice: Number(item.targetPrice),
          active: Boolean(item.active),
          createdAt: item.createdAt || new Date().toISOString()
        }));

        const res = await fetch(`${SUPABASE_URL}/rest/v1/price_alerts`, {
          method: 'POST',
          headers,
          body: JSON.stringify(mappedAlerts)
        });
        if (res.ok) counts.priceAlerts = mappedAlerts.length;
      }

      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Bulk synced tables to Supabase (${latencyMs}ms)`);
      return {
        success: true,
        syncedCounts: counts
      };
    } catch (err: unknown) {
      console.error('Supabase bulkSync error:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      this.setOffline(`Bulk sync error: ${errMsg}`);
      return {
        success: false,
        syncedCounts: counts,
        error: errMsg
      };
    }
  }

  static async fetchListingsFromSupabase(): Promise<Listing[] | null> {
    const startTime = Date.now();
    this.setSyncing('Fetching listings from Supabase...');
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/listings?select=*&order=createdAt.desc`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const latencyMs = Date.now() - startTime;
      if (res.ok) {
        const raw = await res.json();
        this.setSynced(latencyMs, `Live connection active (${latencyMs}ms)`);
        if (Array.isArray(raw)) {
          return raw.map((item: any) => ({
            id: String(item.id),
            title: String(item.title || 'Untitled Experience'),
            description: String(item.description || ''),
            category: (item.category as any) || 'PLACE',
            location: String(item.location || 'Explore Location'),
            country: String(item.country || 'Global'),
            price: Number(item.price || 199),
            rating: Number(item.rating || 4.9),
            reviewCount: Number(item.reviewCount || 12),
            images: Array.isArray(item.images)
              ? item.images
              : (typeof item.images === 'string' && item.images.startsWith('[')
                ? JSON.parse(item.images)
                : ['https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80']),
            status: item.status || 'PUBLISHED',
            tags: Array.isArray(item.tags) ? item.tags : ['Curated', 'Supabase Verified'],
            amenities: Array.isArray(item.amenities) ? item.amenities : ['WiFi', 'Scenic View'],
            createdBy: item.createdBy || 'super_admin_001',
            createdByName: item.createdByName || 'Super Admin',
            timestamps: {
              createdAt: item.createdAt || new Date().toISOString(),
              updatedAt: item.createdAt || new Date().toISOString()
            }
          }));
        }
      } else {
        // Table may not exist yet in schema cache, keep state graceful
        this.setSynced(latencyMs, `Supabase API reachable (${latencyMs}ms)`);
      }
    } catch (err) {
      console.warn('[SupabaseSync] Direct fetch from Supabase failed:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      this.setOffline(`Supabase offline: ${errMsg}`);
    }
    return null;
  }

  static async syncSingleListing(item: Listing): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing(`Backing up "${item.title.substring(0, 16)}..." to Supabase...`);
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      };

      const mappedListing = {
        id: item.id,
        title: item.title,
        description: item.description,
        category: item.category,
        location: item.location,
        country: item.country,
        price: Number(item.price),
        rating: Number(item.rating || 5.0),
        images: item.images,
        status: item.status,
        createdAt: item.timestamps?.createdAt || new Date().toISOString()
      };

      const res = await fetch(`${SUPABASE_URL}/rest/v1/listings`, {
        method: 'POST',
        headers,
        body: JSON.stringify(mappedListing)
      });
      const latencyMs = Date.now() - startTime;
      if (res.ok) {
        this.setSynced(latencyMs, `Backed up to Supabase (${latencyMs}ms)`);
        return true;
      } else {
        this.setSynced(latencyMs, `Supabase connection verified`);
        return false;
      }
    } catch (err) {
      console.error('Error syncing single listing to Supabase:', err);
      this.setOffline('Failed to backup listing to Supabase');
      return false;
    }
  }

  static async deleteSingleListing(id: string): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing(`Syncing deletion (${id}) to Supabase...`);
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      };

      const res = await fetch(`${SUPABASE_URL}/rest/v1/listings?id=eq.${id}`, {
        method: 'DELETE',
        headers
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Deleted from Supabase (${latencyMs}ms)`);
      return res.ok;
    } catch (err) {
      console.error('Error deleting single listing from Supabase:', err);
      this.setOffline('Failed to delete listing on Supabase');
      return false;
    }
  }

  static async deleteAllListings(): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing('Clearing Supabase catalog cache...');
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      };

      // A "not equal to impossible value" filter is required because PostgREST
      // refuses an unfiltered DELETE across an entire table.
      const res = await fetch(`${SUPABASE_URL}/rest/v1/listings?id=neq.__never__`, {
        method: 'DELETE',
        headers
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Purged from Supabase (${latencyMs}ms)`);
      return res.ok;
    } catch (err) {
      console.error('Error clearing all listings from Supabase:', err);
      this.setOffline('Failed to clear Supabase catalog');
      return false;
    }
  }

  // ==========================================================
  // FEED POSTS (Admin Broadcasts / Announcements)
  // These are what makes an admin's post visible to every
  // device: the Express /api/feed-posts route only exists in
  // local dev, so on the deployed static site this Supabase
  // table is the real source of truth.
  // ==========================================================

  static async fetchFeedPostsFromSupabase(): Promise<FeedPost[] | null> {
    const startTime = Date.now();
    this.setSyncing('Fetching announcements from Supabase...');
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/feed_posts?select=*&order=createdAt.desc`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const latencyMs = Date.now() - startTime;
      if (res.ok) {
        const raw = await res.json();
        this.setSynced(latencyMs, `Announcements synced (${latencyMs}ms)`);
        if (Array.isArray(raw)) {
          return raw.map((item: any) => ({
            id: String(item.id),
            authorId: String(item.authorId || ''),
            authorName: String(item.authorName || 'Admin'),
            content: String(item.content || ''),
            createdAt: item.createdAt || new Date().toISOString()
          }));
        }
        return [];
      }
      this.setSynced(latencyMs, 'Supabase API reachable');
    } catch (err) {
      console.warn('[SupabaseSync] Fetching feed posts failed:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      this.setOffline(`Supabase offline: ${errMsg}`);
    }
    return null;
  }

  static async createFeedPostInSupabase(post: FeedPost): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing('Broadcasting announcement to Supabase...');
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      };
      const res = await fetch(`${SUPABASE_URL}/rest/v1/feed_posts`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          id: post.id,
          authorId: post.authorId,
          authorName: post.authorName,
          content: post.content,
          createdAt: post.createdAt
        })
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Announcement broadcast (${latencyMs}ms)`);
      return res.ok;
    } catch (err) {
      console.error('Error creating feed post in Supabase:', err);
      this.setOffline('Failed to broadcast announcement');
      return false;
    }
  }

  static async deleteFeedPostInSupabase(id: string): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing('Removing announcement from Supabase...');
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      };
      const res = await fetch(`${SUPABASE_URL}/rest/v1/feed_posts?id=eq.${id}`, {
        method: 'DELETE',
        headers
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Announcement removed (${latencyMs}ms)`);
      return res.ok;
    } catch (err) {
      console.error('Error deleting feed post in Supabase:', err);
      this.setOffline('Failed to remove announcement');
      return false;
    }
  }

  static async deleteAllFeedPostsInSupabase(): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing('Clearing all announcements in Supabase...');
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
      };
      const res = await fetch(`${SUPABASE_URL}/rest/v1/feed_posts?id=neq.__never__`, {
        method: 'DELETE',
        headers
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, 'Announcements cleared');
      return res.ok;
    } catch (err) {
      console.error('Error clearing feed posts in Supabase:', err);
      this.setOffline('Failed to clear announcements');
      return false;
    }
  }

  // ==========================================================
  // USERS (needed so a returning user keeps their role/profile
  // no matter which device or browser they sign back in from)
  // ==========================================================

  static async upsertUserToSupabase(user: User): Promise<boolean> {
    const startTime = Date.now();
    this.setSyncing('Saving sign-in details to Supabase...');
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      };
      const mappedUser = {
        uid: user.uid,
        name: user.name,
        email: user.email,
        role: user.role,
        customTitle: user.customTitle || null,
        department: user.department || null,
        avatar: user.avatar || null,
        mfaEnabled: Boolean(user.mfaEnabled),
        status: user.status || 'ACTIVE',
        lastLoginAt: user.lastLoginAt || new Date().toISOString(),
        createdAt: user.createdAt || new Date().toISOString()
      };
      const res = await fetch(`${SUPABASE_URL}/rest/v1/users`, {
        method: 'POST',
        headers,
        body: JSON.stringify(mappedUser)
      });
      const latencyMs = Date.now() - startTime;
      this.setSynced(latencyMs, `Sign-in details saved (${latencyMs}ms)`);
      return res.ok;
    } catch (err) {
      console.error('Error saving user to Supabase:', err);
      this.setOffline('Failed to save sign-in details');
      return false;
    }
  }

  static async fetchUsersFromSupabase(): Promise<User[] | null> {
    const startTime = Date.now();
    this.setSyncing('Fetching users from Supabase...');
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/users?select=*&order=createdAt.desc`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      const latencyMs = Date.now() - startTime;
      if (res.ok) {
        const raw = await res.json();
        this.setSynced(latencyMs, `Users synced (${latencyMs}ms)`);
        if (Array.isArray(raw)) {
          return raw.map((item: any) => ({
            uid: String(item.uid),
            email: String(item.email || ''),
            name: String(item.name || 'Traveler'),
            role: item.role || 'USER',
            customTitle: item.customTitle || undefined,
            department: item.department || undefined,
            avatar: item.avatar || undefined,
            mfaEnabled: Boolean(item.mfaEnabled),
            status: item.status || 'ACTIVE',
            lastLoginAt: item.lastLoginAt || undefined,
            createdAt: item.createdAt || new Date().toISOString()
          }));
        }
        return [];
      }
      this.setSynced(latencyMs, 'Supabase API reachable');
    } catch (err) {
      console.warn('[SupabaseSync] Fetching users failed:', err);
      const errMsg = err instanceof Error ? err.message : String(err);
      this.setOffline(`Supabase offline: ${errMsg}`);
    }
    return null;
  }

  static async upsertCustomPostToSupabase(post: CustomPost): Promise<boolean> {
    try {
      const headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      };
      const res = await fetch(`${SUPABASE_URL}/rest/v1/custom_posts`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          id: post.id,
          title: post.title,
          description: post.description,
          department: post.department,
          privileges: post.privileges,
          baseRole: post.baseRole || 'ADMIN',
          createdAt: post.createdAt || new Date().toISOString()
        })
      });
      return res.ok;
    } catch (err) {
      console.error('Error saving custom post to Supabase:', err);
      return false;
    }
  }

  /** Looks up a single returning user by email, used to restore their real role/profile on a new device instead of re-provisioning them as a fresh USER. */
  static async fetchUserByEmail(email: string): Promise<User | null> {
    if (!email) return null;
    try {
      const res = await fetch(`${SUPABASE_URL}/rest/v1/users?email=eq.${encodeURIComponent(email.trim().toLowerCase())}&select=*&limit=1`, {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`
        }
      });
      if (!res.ok) return null;
      const raw = await res.json();
      if (!Array.isArray(raw) || raw.length === 0) return null;
      const item = raw[0];
      return {
        uid: String(item.uid),
        email: String(item.email || ''),
        name: String(item.name || 'Traveler'),
        role: item.role || 'USER',
        customTitle: item.customTitle || undefined,
        department: item.department || undefined,
        avatar: item.avatar || undefined,
        mfaEnabled: Boolean(item.mfaEnabled),
        status: item.status || 'ACTIVE',
        lastLoginAt: item.lastLoginAt || undefined,
        createdAt: item.createdAt || new Date().toISOString()
      };
    } catch (err) {
      console.warn('[SupabaseSync] fetchUserByEmail failed:', err);
      return null;
    }
  }
}
