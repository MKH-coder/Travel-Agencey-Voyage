# Voyage — Travel Platform

A React + TypeScript travel discovery site with an admin portal (listing approvals,
role management, broadcast announcements) and an Express backend for local
development. The production site deploys as a **static build to GitHub Pages**.

## How it's actually deployed (read this first)

`npm run deploy` / the GitHub Actions workflow in `.github/workflows/deploy.yml`
only runs `vite build` and publishes the `dist/` folder to GitHub Pages. GitHub
Pages serves static files only — **it cannot run `server.ts`**. That means on
the live site, none of the `/api/...` routes exist.

So the app is written to always try the server first and fall back automatically:

1. Try the local Express API (`/api/...`) — only succeeds when you run `npm run dev`.
2. Fall back to **Supabase** (`src/services/supabaseSync.ts`), talked to directly
   from the browser with the public anon key. This is what actually makes data
   visible across every device on the live site.
3. Fall back to `localStorage` (`src/services/clientStorage.ts`) only as an
   offline cache for the current browser.

**This was the bug behind "posts don't show on other devices":** the admin
broadcast feed (`ExploreFeed.tsx`) and the users list only had step 1 and step 3 —
there was no Supabase fallback, so on the deployed site every post and every
signed-in account was trapped in whichever single browser created it. That's
now fixed — see "What changed" below.

## One-time setup: Supabase tables

Before posts/listings/logins will sync across devices, run `supabase/schema.sql`
once in your Supabase project's SQL editor (Dashboard → SQL Editor → New query).
It creates the `listings`, `feed_posts`, `users`, `custom_posts`, `audit_logs`,
`bookings`, and `price_alerts` tables the app already expects, with permissive
Row Level Security policies matching how the app currently authenticates
(directly with the anon key, no server-side gate).

`data/site-content.json` has a small set of sample listings, admin role
definitions, and one example announcement in the exact shape the app reads —
useful either as a manual seed (paste rows into the Supabase table editor) or
as a reference for the JSON shape if you add your own import script.

## ⚠️ Before you make this repo public

A few things in this codebase should not go into a public GitHub repo as-is:

- **Hardcoded 2FA/emergency-bypass codes** in `src/context/AuthContext.tsx`
  and `src/data/defaultData.ts` (e.g. the `isBypass` password list). These
  ship inside the JavaScript bundle, so anyone can open dev tools, read them,
  and log in as a super admin. Move these to a server-only secret checked by
  `server.ts`, or remove the client-side bypass path entirely.
- **Real personal emails/phone numbers** hardcoded into `DEFAULT_USERS` /
  `INITIAL_USERS` (`src/data/defaultData.ts`, `src/services/clientStorage.ts`).
  Consider replacing with placeholder data before publishing.
- The Supabase **RLS policies in `supabase/schema.sql` are wide open**
  (anyone with the anon key — which is public in the bundle — can read AND
  write every table). That matches how the app behaves today, but it means
  anyone could delete your whole catalogue via the API directly, not just
  through the admin UI. Tighten these policies before relying on this for
  real user data.
- Double-check `.env` is never committed — `.gitignore` already excludes
  `.env*` (except `.env.example`), just confirm you never used `git add -f`.

None of this blocks pushing to GitHub — it's about what happens once the
repo/site is public.

## Importing content from a JSON file

In the Admin Portal, elevated admins (Admin/Sub-Admin/Tech Admin) now have a
**Cloud & GitHub Sync** tab with a JSON upload box. Upload a `.json` file
shaped like `data/site-content.json`:

```json
{
  "listings": [ { "title": "...", "category": "PLACE", "description": "...", "images": ["..."] } ],
  "feedPosts": [ { "content": "Announcement text..." } ],
  "customPosts": [ { "title": "Role name", "privileges": ["PUBLISH_DIRECTLY"] } ]
}
```

Every item is published straight to Supabase (and cached locally), so it
shows up for anyone opening the site on any device — the same path the
"Post" button and listing approvals use. The panel tells you exactly how many
items succeeded; if it reports `0/N` published, the Supabase tables almost
certainly haven't been created yet — see the next section.

**If "nothing happens" when you post, import, or log in:** it's almost always
because the Supabase tables don't exist yet. Run `supabase/schema.sql` in your
Supabase project's SQL editor first (see below) — until those tables exist,
every sync call in this app fails quietly and falls back to this one browser's
local storage, which looks like nothing happened.

## What changed in this pass

- `src/services/supabaseSync.ts` — added `feed_posts` and `users` sync
  (fetch/create/delete/upsert), so broadcasts and accounts are no longer
  localStorage-only.
- `src/components/ExploreFeed.tsx` — admin broadcast posts now publish to
  Supabase (with the local server as an optional first try) and every open
  browser polls and picks them up, instead of silently no-oping in production.
- `src/context/AuthContext.tsx` — a returning user's session is now checked
  against Supabase on load, and their saved role/title is looked up by email
  on login instead of being reset to plain `USER` on a new device. Every
  sign-in also upserts the account into the shared `users` table.
- `src/components/AdminPortal.tsx` — the Users and Listings tabs now merge in
  data from Supabase, not just the local server/cache, so admins can see
  activity from any device. "Clear Entire Catalog" now also clears all
  broadcast announcements everywhere (local + server + Supabase), i.e. a real
  "delete master catalogue" action.
- `server.ts` / `server/db.ts` — added a bulk `DELETE /api/feed-posts` route
  (for local dev parity with the new catalogue-wide delete).
- `supabase/schema.sql`, `data/site-content.json` — new files, described above.

## Local development

```bash
npm install
cp .env.example .env   # fill in your Supabase URL/keys
npm run dev             # runs the Express + Vite dev server (server.ts)
```

## Verifying before you push

I could not run `npm install` / `npm run build` / `npm run lint` in the
environment these changes were made in (no network access there). Please run,
in order, before pushing:

```bash
npm install
npm run lint     # tsc --noEmit — catches any type errors
npm run build    # vite build — confirms the static site still builds
```

## Deploying

```bash
git add .
git commit -m "Fix cross-device sync for posts and logins; add master catalogue delete"
git push origin main
```

The GitHub Actions workflow (`.github/workflows/deploy.yml`) then builds and
publishes to GitHub Pages automatically on push to `main`/`master`. Make sure
GitHub Pages is set to the "GitHub Actions" source in the repo's Settings →
Pages, and that the Supabase table setup above is done first.
